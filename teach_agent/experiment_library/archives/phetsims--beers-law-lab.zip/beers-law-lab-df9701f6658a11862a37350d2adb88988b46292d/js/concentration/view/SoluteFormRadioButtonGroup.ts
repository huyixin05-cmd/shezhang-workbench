// Copyright 2013-2026, University of Colorado Boulder

/**
 * Radio button group that selects the solute form, either solid (shaker) or solution (dropper).
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import EnumerationProperty from '../../../../axon/js/EnumerationProperty.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import optionize, { EmptySelfOptions } from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import PhetFont from '../../../../scenery-phet/js/PhetFont.js';
import HBox from '../../../../scenery/js/layout/nodes/HBox.js';
import Image from '../../../../scenery/js/nodes/Image.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import Text from '../../../../scenery/js/nodes/Text.js';
import AquaRadioButtonGroup, { AquaRadioButtonGroupItem, AquaRadioButtonGroupOptions } from '../../../../sun/js/AquaRadioButtonGroup.js';
import dropperIcon_png from '../../../images/dropperIcon_png.js';
import shakerIcon_png from '../../../images/shakerIcon_png.js';
import BeersLawLabStrings from '../../BeersLawLabStrings.js';
import BLLConstants from '../../common/BLLConstants.js';
import SoluteForm from '../model/SoluteForm.js';

type SelfOptions = EmptySelfOptions;

type SoluteFormRadioButtonGroupOptions = SelfOptions & PickRequired<AquaRadioButtonGroupOptions, 'tandem'>;

export default class SoluteFormRadioButtonGroup extends AquaRadioButtonGroup<SoluteForm> {

  public constructor( soluteFormProperty: EnumerationProperty<SoluteForm>,
                      providedOptions: SoluteFormRadioButtonGroupOptions ) {

    const options = optionize<SoluteFormRadioButtonGroupOptions, SelfOptions, AquaRadioButtonGroupOptions>()( {

      // AquaRadioButtonGroupOptions
      isDisposable: false,
      orientation: 'horizontal',
      spacing: 60,
      radioButtonOptions: {
        radius: BLLConstants.RADIO_BUTTON_RADIUS
      },
      touchAreaXDilation: 8,
      touchAreaYDilation: 3,
      mouseAreaXDilation: 8,
      mouseAreaYDilation: 3,
      accessibleName: BeersLawLabStrings.a11y.soluteFormRadioButtonGroup.accessibleNameStringProperty
    }, providedOptions );

    // radio button descriptions
    const items: AquaRadioButtonGroupItem<SoluteForm>[] = [
      {
        value: SoluteForm.SOLID,
        createNode: tandem => createRadioButtonLabel( BeersLawLabStrings.solidStringProperty, shakerIcon_png ),
        options: {
          accessibleName: BeersLawLabStrings.a11y.solidRadioButton.accessibleNameStringProperty
        },
        tandemName: 'solidRadioButton'
      },
      {
        value: SoluteForm.SOLUTION,
        createNode: tandem => createRadioButtonLabel( BeersLawLabStrings.solutionStringProperty, dropperIcon_png ),
        options: {
          accessibleName: BeersLawLabStrings.a11y.solutionRadioButton.accessibleNameStringProperty
        },
        tandemName: 'solutionRadioButton'
      }
    ];

    super( soluteFormProperty, items, options );
  }
}

/**
 * Creates the label for a radio button.
 */
function createRadioButtonLabel( text: TReadOnlyProperty<string>, image: HTMLImageElement ): Node {
  return new HBox( {
    spacing: 10,
    children: [
      new Text( text, {
        font: new PhetFont( 22 ),
        fill: 'black',
        maxWidth: 100
      } ),
      new Image( image )
    ]
  } );
}
