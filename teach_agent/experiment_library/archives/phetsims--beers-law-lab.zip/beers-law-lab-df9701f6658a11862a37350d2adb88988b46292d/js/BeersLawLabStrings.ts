// Copyright 2021-2026, University of Colorado Boulder

/* eslint-disable */
/* @formatter:off */

/**
 * Auto-generated from modulify, DO NOT manually modify.
 */

import getStringModule from '../../chipper/js/browser/getStringModule.js';
import type LocalizedStringProperty from '../../chipper/js/browser/LocalizedStringProperty.js';
import beersLawLab from './beersLawLab.js';

type StringsType = {
  'absorbanceStringProperty': LocalizedStringProperty;
  'beers-law-lab': {
    'titleStringProperty': LocalizedStringProperty;
  };
  'cobaltIINitrateStringProperty': LocalizedStringProperty;
  'cobaltChlorideStringProperty': LocalizedStringProperty;
  'concentrationStringProperty': LocalizedStringProperty;
  'copperSulfateStringProperty': LocalizedStringProperty;
  'drinkMixStringProperty': LocalizedStringProperty;
  'evaporationStringProperty': LocalizedStringProperty;
  'presetStringProperty': LocalizedStringProperty;
  'lotsStringProperty': LocalizedStringProperty;
  'nickelIIChlorideStringProperty': LocalizedStringProperty;
  'noneStringProperty': LocalizedStringProperty;
  'pattern': {
    '0labelStringProperty': LocalizedStringProperty;
    '0value': {
      '1unitsStringProperty': LocalizedStringProperty;
    };
    '0percentStringProperty': LocalizedStringProperty;
    '0formula': {
      '1nameStringProperty': LocalizedStringProperty;
    };
    '0soluteAmountStringProperty': LocalizedStringProperty;
  };
  'potassiumChromateStringProperty': LocalizedStringProperty;
  'potassiumDichromateStringProperty': LocalizedStringProperty;
  'potassiumPermanganateStringProperty': LocalizedStringProperty;
  'removeSoluteStringProperty': LocalizedStringProperty;
  'saturatedStringProperty': LocalizedStringProperty;
  'sodiumChlorideStringProperty': LocalizedStringProperty;
  'solidStringProperty': LocalizedStringProperty;
  'soluteStringProperty': LocalizedStringProperty;
  'solutionStringProperty': LocalizedStringProperty;
  'screen': {
    'concentrationStringProperty': LocalizedStringProperty;
    'beersLawStringProperty': LocalizedStringProperty;
  };
  'transmittanceStringProperty': LocalizedStringProperty;
  'units': {
    'centimetersStringProperty': LocalizedStringProperty;
    'litersStringProperty': LocalizedStringProperty;
    'millilitersStringProperty': LocalizedStringProperty;
    'molesPerLiterStringProperty': LocalizedStringProperty;
    'mMStringProperty': LocalizedStringProperty;
    'uMStringProperty': LocalizedStringProperty;
    'nmStringProperty': LocalizedStringProperty;
    'percentStringProperty': LocalizedStringProperty;
  };
  'variableStringProperty': LocalizedStringProperty;
  'wavelengthStringProperty': LocalizedStringProperty;
  'showSolutionVolumeStringProperty': LocalizedStringProperty;
  'showSoluteAmountStringProperty': LocalizedStringProperty;
  'beakerUnitsStringProperty': LocalizedStringProperty;
  'concentrationMeterUnitsStringProperty': LocalizedStringProperty;
  'keyboardHelpDialog': {
    'chooseASoluteStringProperty': LocalizedStringProperty;
    'soluteStringProperty': LocalizedStringProperty;
    'solutesStringProperty': LocalizedStringProperty;
    'chooseASolutionStringProperty': LocalizedStringProperty;
    'solutionStringProperty': LocalizedStringProperty;
    'solutionsStringProperty': LocalizedStringProperty;
    'concentrationProbeControlsStringProperty': LocalizedStringProperty;
    'detectorProbeAndRulerControlsStringProperty': LocalizedStringProperty;
    'jumpToPositionStringProperty': LocalizedStringProperty;
  };
  'a11y': {
    'concentrationScreen': {
      'screenButtonsHelpTextStringProperty': LocalizedStringProperty;
      'screenSummary': {
        'playAreaStringProperty': LocalizedStringProperty;
        'controlAreaStringProperty': LocalizedStringProperty;
        'currentDetails': {
          'beakerEmptyStringProperty': LocalizedStringProperty;
          'onlyParticlesStringProperty': LocalizedStringProperty;
          'onlyWaterConcentrationMeasuredStringProperty': LocalizedStringProperty;
          'onlyWaterConcentrationNotMeasuredStringProperty': LocalizedStringProperty;
          'solutionConcentrationMeasuredStringProperty': LocalizedStringProperty;
          'solutionConcentrationNotMeasuredStringProperty': LocalizedStringProperty;
        };
        'interactionHintStringProperty': LocalizedStringProperty;
      }
    };
    'beersLawScreen': {
      'screenButtonsHelpTextStringProperty': LocalizedStringProperty;
      'screenSummary': {
        'playAreaStringProperty': LocalizedStringProperty;
        'controlAreaStringProperty': LocalizedStringProperty;
        'currentDetails': {
          'noMeasurementStringProperty': LocalizedStringProperty;
          'measuredTransmittanceStringProperty': LocalizedStringProperty;
          'measuredAbsorbanceStringProperty': LocalizedStringProperty;
        };
        'interactionHintStringProperty': LocalizedStringProperty;
      }
    };
    'soluteFormRadioButtonGroup': {
      'accessibleNameStringProperty': LocalizedStringProperty;
    };
    'solidRadioButton': {
      'accessibleNameStringProperty': LocalizedStringProperty;
    };
    'solutionRadioButton': {
      'accessibleNameStringProperty': LocalizedStringProperty;
    };
    'lightModeRadioButtonGroup': {
      'accessibleNameStringProperty': LocalizedStringProperty;
    };
    'detectorModeRadioButtonGroup': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'wavelengthNumberControl': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'ariaValueTextStringProperty': LocalizedStringProperty;
    };
    'concentrationProbeNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'jumpResponses': {
        'inBeakerStringProperty': LocalizedStringProperty;
        'insideEmptyBeakerStringProperty': LocalizedStringProperty;
        'outsideBeakerStringProperty': LocalizedStringProperty;
        'belowWaterFaucetStringProperty': LocalizedStringProperty;
        'belowDrainFaucetStringProperty': LocalizedStringProperty;
        'belowDropperStringProperty': LocalizedStringProperty;
      }
    };
    'detectorProbeNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'accessibleObjectResponseTransmittanceStringProperty': LocalizedStringProperty;
      'accessibleObjectResponseAbsorbanceStringProperty': LocalizedStringProperty;
      'accessibleObjectResponseUnknownStringProperty': LocalizedStringProperty;
      'jumpResponses': {
        'betweenLightSourceAndCuvetteStringProperty': LocalizedStringProperty;
        'centeredInCuvetteStringProperty': LocalizedStringProperty;
        'rightOfCuvetteStringProperty': LocalizedStringProperty;
        'outsideLightSourcePathStringProperty': LocalizedStringProperty;
      }
    };
    'transmittanceValueUnitsStringProperty': LocalizedStringProperty;
    'transmittanceUnknownStringProperty': LocalizedStringProperty;
    'absorbanceValueStringProperty': LocalizedStringProperty;
    'absorbanceUnknownStringProperty': LocalizedStringProperty;
    'shakerNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'accessibleContextResponseDispensingStringProperty': LocalizedStringProperty;
      'accessibleContextResponseEmptyStringProperty': LocalizedStringProperty;
    };
    'dropperButton': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'accessibleContextResponseDispensingStringProperty': LocalizedStringProperty;
      'accessibleContextResponseBeakerFullStringProperty': LocalizedStringProperty;
      'accessibleContextResponseDropperEmptyStringProperty': LocalizedStringProperty;
    };
    'concentrationMeterBodyNode': {
      'concentrationIsValueUnitsStringProperty': LocalizedStringProperty;
      'concentrationIsUnknownStringProperty': LocalizedStringProperty;
    };
    'soluteComboBox': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'removeSoluteButton': {
      'accessibleContextResponseStringProperty': LocalizedStringProperty;
    };
    'solventFaucetNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'drainFaucetNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'evaporationSlider': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'rulerNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
      'jumpResponses': {
        'measuringCuvetteWidthStringProperty': LocalizedStringProperty;
        'measuringOpticalPathLengthStringProperty': LocalizedStringProperty;
        'measuringOpticalPathLengthLightOffStringProperty': LocalizedStringProperty;
        'notMeasuringStringProperty': LocalizedStringProperty;
      }
    };
    'cuvetteArrowNode': {
      'accessibleNameStringProperty': LocalizedStringProperty;
    };
    'lightToggleButton': {
      'accessibleNameStringProperty': LocalizedStringProperty;
    };
    'soluteAmountText': {
      'accessibleParagraphStringProperty': LocalizedStringProperty;
    };
    'solutionVolumeNode': {
      'accessibleParagraphStringProperty': LocalizedStringProperty;
    };
    'showSolutionVolumeCheckbox': {
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'showSoluteAmountCheckbox': {
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'beakerUnitsRadioButtonGroup': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'concentrationMeterUnitsRadioButtonGroup': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'solutionConcentrationControl': {
      'accessibleNameStringProperty': LocalizedStringProperty;
      'accessibleHelpTextStringProperty': LocalizedStringProperty;
    };
    'sharedAccessibleContextResponses': {
      'presetWavelengthSetStringProperty': LocalizedStringProperty;
    };
    'colorNames': {
      'redStringProperty': LocalizedStringProperty;
      'orangeStringProperty': LocalizedStringProperty;
      'yellowStringProperty': LocalizedStringProperty;
      'greenStringProperty': LocalizedStringProperty;
      'blueStringProperty': LocalizedStringProperty;
      'violetStringProperty': LocalizedStringProperty;
    };
    'onStringProperty': LocalizedStringProperty;
    'offStringProperty': LocalizedStringProperty;
    'solutionIsSaturatedStringProperty': LocalizedStringProperty;
    'solutionIsNotSaturatedStringProperty': LocalizedStringProperty;
    'accessibleHeadings': {
      'soluteControlsHeadingStringProperty': LocalizedStringProperty;
      'concentrationMeterHeadingStringProperty': LocalizedStringProperty;
      'beakerControlsHeadingStringProperty': LocalizedStringProperty;
      'lightSourceControlsHeadingStringProperty': LocalizedStringProperty;
      'detectorControlsHeadingStringProperty': LocalizedStringProperty;
      'solutionControlsHeadingStringProperty': LocalizedStringProperty;
    };
    'valueUnitsPatternStringProperty': LocalizedStringProperty;
    'unitsDescription': {
      'centimetersStringProperty': LocalizedStringProperty;
      'gramsStringProperty': LocalizedStringProperty;
      'litersStringProperty': LocalizedStringProperty;
      'litersPerSecondStringProperty': LocalizedStringProperty;
      'micromolarStringProperty': LocalizedStringProperty;
      'millilitersStringProperty': LocalizedStringProperty;
      'millilitersPerSecondStringProperty': LocalizedStringProperty;
      'millimolarStringProperty': LocalizedStringProperty;
      'molesPerLiterStringProperty': LocalizedStringProperty;
      'nanometersStringProperty': LocalizedStringProperty;
      'percentStringProperty': LocalizedStringProperty;
    }
  }
};

const BeersLawLabStrings = getStringModule( 'BEERS_LAW_LAB' ) as StringsType;

beersLawLab.register( 'BeersLawLabStrings', BeersLawLabStrings );

export default BeersLawLabStrings;
