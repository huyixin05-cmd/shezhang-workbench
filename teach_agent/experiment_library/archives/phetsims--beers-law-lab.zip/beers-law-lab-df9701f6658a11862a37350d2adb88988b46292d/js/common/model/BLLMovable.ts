// Copyright 2013-2026, University of Colorado Boulder

/**
 * BLLMovable is a movable model element.
 * Semantics of units are determined by the client.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import Property from '../../../../axon/js/Property.js';
import Bounds2 from '../../../../dot/js/Bounds2.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import Vector2Property from '../../../../dot/js/Vector2Property.js';
import optionize from '../../../../phet-core/js/optionize.js';
import PickOptional from '../../../../phet-core/js/types/PickOptional.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import PhetioObject, { PhetioObjectOptions } from '../../../../tandem/js/PhetioObject.js';

type SelfOptions = {
  position?: Vector2; // initial position
  positionPropertyFeatured?: boolean; // whether positionProperty is phetioFeatured
  positionPropertyReadOnly?: boolean; // whether positionProperty is read-only
  dragBounds?: Bounds2; // drag bounds
};

export type BLLMovableOptions = SelfOptions &
  PickRequired<PhetioObjectOptions, 'tandem'> &
  PickOptional<PhetioObjectOptions, 'phetioState'>;

export default class BLLMovable extends PhetioObject {

  public readonly positionProperty: Property<Vector2>;
  public readonly dragBounds: Bounds2;

  public constructor( providedOptions: BLLMovableOptions ) {

    const options = optionize<BLLMovableOptions, SelfOptions, PhetioObjectOptions>()( {

      // SelfOptions
      position: Vector2.ZERO,
      positionPropertyFeatured: true,
      positionPropertyReadOnly: true,
      dragBounds: Bounds2.EVERYTHING,

      // PhetioObjectOptions
      isDisposable: false,
      phetioState: false
    }, providedOptions );

    super( options );

    this.positionProperty = new Vector2Property( options.position, {
      units: 'cm',
      tandem: options.tandem.createTandem( 'positionProperty' ),
      phetioFeatured: options.positionPropertyFeatured,
      phetioReadOnly: options.positionPropertyReadOnly,
      phetioDocumentation: 'Note that (0,0) is at the upper-LEFT, +x is to the right, and +y is DOWN.'
    } );

    this.dragBounds = options.dragBounds;
  }

  public reset(): void {
    this.positionProperty.reset();
  }
}
