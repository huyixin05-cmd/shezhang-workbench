// Copyright 2013-2026, University of Colorado Boulder

/**
 * Detector measure transmittance (%T) and absorbance (A) of light passing through a solution in a cuvette.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import DerivedProperty from '../../../../axon/js/DerivedProperty.js';
import EnumerationProperty from '../../../../axon/js/EnumerationProperty.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';
import Bounds2 from '../../../../dot/js/Bounds2.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import optionize from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import PhetioObject, { PhetioObjectOptions } from '../../../../tandem/js/PhetioObject.js';
import NullableIO from '../../../../tandem/js/types/NullableIO.js';
import NumberIO from '../../../../tandem/js/types/NumberIO.js';
import BLLMovable, { BLLMovableOptions } from '../../common/model/BLLMovable.js';
import DetectorMode from './DetectorMode.js';
import Cuvette from './Cuvette.js';
import Light from './Light.js';
import SolutionInCuvette from './SolutionInCuvette.js';

type SelfOptions = {
  bodyPosition?: Vector2;
  probePosition?: Vector2;
  probeDragBounds?: Bounds2;
};

type DetectorOptions = SelfOptions & PickRequired<PhetioObjectOptions, 'tandem'>;

export default class Detector extends PhetioObject {

  private readonly light: Light;
  public readonly body: BLLMovable;
  public readonly probe: Probe;
  public readonly modeProperty: EnumerationProperty<DetectorMode>;
  public readonly isInBeamProperty: TReadOnlyProperty<boolean>;
  public readonly pathLengthProperty: TReadOnlyProperty<number | null>;

  public readonly absorbanceProperty: TReadOnlyProperty<number | null>;
  public readonly transmittanceProperty: TReadOnlyProperty<number | null>;

  public constructor( light: Light, cuvette: Cuvette, solutionInCuvette: SolutionInCuvette, providedOptions: DetectorOptions ) {

    const options = optionize<DetectorOptions, SelfOptions, PhetioObjectOptions>()( {
      bodyPosition: Vector2.ZERO,
      probePosition: Vector2.ZERO,
      probeDragBounds: Bounds2.EVERYTHING,
      isDisposable: false,
      phetioState: false
    }, providedOptions );

    super( options );

    this.light = light;

    this.body = new BLLMovable( {
      position: options.bodyPosition,
      tandem: options.tandem.createTandem( 'body' ),
      positionPropertyFeatured: false
    } );

    this.probe = new Probe( {
      sensorDiameter: 0.57,
      position: options.probePosition,
      dragBounds: options.probeDragBounds,
      tandem: options.tandem.createTandem( 'probe' )
    } );

    this.modeProperty = new EnumerationProperty( DetectorMode.TRANSMITTANCE, {
      tandem: options.tandem.createTandem( 'modeProperty' ),
      phetioFeatured: true
    } );

    this.pathLengthProperty = new DerivedProperty( [ this.light.isOnProperty, this.probe.positionProperty, cuvette.widthProperty ],
      ( lightIsOn, probePosition, cuvetteWidth ) =>
        ( lightIsOn && this.isProbeInBeam() ) ? Math.min( Math.max( 0, probePosition.x - cuvette.position.x ), cuvetteWidth ) : null, {
        units: 'cm',
        tandem: options.tandem.createTandem( 'pathLengthProperty' ),
        phetioFeatured: true,
        phetioValueType: NullableIO( NumberIO ),
        phetioDocumentation: 'The distance that the light beam passes through the solution before hitting the probe. ' +
                             'null if the light is off or the probe is not in the beam.'
      } );

    this.absorbanceProperty = new DerivedProperty(
      [ solutionInCuvette.molarAbsorptivityProperty, this.pathLengthProperty, solutionInCuvette.concentrationProperty ],
      ( molarAbsorptivity, pathLength, concentration ) =>
        ( pathLength === null ) ? null : SolutionInCuvette.getAbsorbance( molarAbsorptivity, pathLength, concentration ), {
        tandem: options.tandem.createTandem( 'absorbanceProperty' ),
        phetioFeatured: true,
        phetioValueType: NullableIO( NumberIO ),
        phetioDocumentation: 'Absorbance at the position of the probe, null if the probe is not in the light beam'
      } );

    this.transmittanceProperty = new DerivedProperty(
      [ this.absorbanceProperty ],
      absorbance => ( absorbance === null ) ? null : SolutionInCuvette.getTransmittance( absorbance ), {
        tandem: options.tandem.createTandem( 'transmittanceProperty' ),
        phetioFeatured: true,
        phetioValueType: NullableIO( NumberIO ),
        phetioDocumentation: 'Transmittance at the position of the probe, null if the probe is not in the light beam'
      } );

    this.isInBeamProperty = new DerivedProperty( [ this.absorbanceProperty ], absorbance => absorbance !== null );
  }

  public reset(): void {
    this.body.reset();
    this.probe.reset();
    this.modeProperty.reset();
  }

  /**
   * Is the probe in some segment of the beam?
   */
  public isProbeInBeam(): boolean {
    return this.light.isOnProperty.value &&
           ( this.probe.getMinY() < this.light.getMinY() ) &&
           ( this.probe.getMaxY() > this.light.getMaxY() ) &&
           ( this.probe.positionProperty.value.x > this.light.position.x );
  }
}

/**
 * Probe is the probe part of the detector, whose position indicates where the measurement is being made.
 */
type ProbeSelfOptions = {
  sensorDiameter?: number; // in cm
};
type ProbeOptions = ProbeSelfOptions & BLLMovableOptions;

class Probe extends BLLMovable {

  public readonly sensorDiameter: number;

  public constructor( providedOptions: ProbeOptions ) {

    const options = optionize<ProbeOptions, ProbeSelfOptions, BLLMovableOptions>()( {

      // ProbeSelfOptions
      sensorDiameter: 1,

      // BLLMovableOptions
      positionPropertyReadOnly: false
    }, providedOptions );

    super( options );

    this.sensorDiameter = options.sensorDiameter;
  }

  public getMinY(): number {
    return this.positionProperty.value.y - ( this.sensorDiameter / 2 );
  }

  public getMaxY(): number {
    return this.positionProperty.value.y + ( this.sensorDiameter / 2 );
  }
}
