// Copyright 2013-2026, University of Colorado Boulder

/**
 * Light is the model of a simple light.
 * Origin is at the center of the lens.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import BooleanProperty from '../../../../axon/js/BooleanProperty.js';
import EnumerationProperty from '../../../../axon/js/EnumerationProperty.js';
import NumberProperty from '../../../../axon/js/NumberProperty.js';
import Property from '../../../../axon/js/Property.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import optionize from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import PhetioObject, { PhetioObjectOptions } from '../../../../tandem/js/PhetioObject.js';
import BeersLawSolution from './BeersLawSolution.js';
import LightMode from './LightMode.js';
import BLLConstants from '../../common/BLLConstants.js';

type SelfOptions = {
  position?: Vector2; // cm
  lensDiameter?: 0.45; // cm
  isOn?: false;
};

type LightOptions = SelfOptions & PickRequired<PhetioObjectOptions, 'tandem'>;

export default class Light extends PhetioObject {

  public readonly position: Vector2;
  public readonly lensDiameter: number;
  public readonly isOnProperty: Property<boolean>;
  public readonly wavelengthProperty: NumberProperty;
  public readonly modeProperty: EnumerationProperty<LightMode>;

  public constructor( solutionProperty: Property<BeersLawSolution>, providedOptions: LightOptions ) {

    const options = optionize<LightOptions, SelfOptions, PhetioObjectOptions>()( {

      // SelfOptions
      position: Vector2.ZERO, // cm
      lensDiameter: 0.45, // cm
      isOn: false,

      // PhetioObjectOptions
      isDisposable: false,
      phetioState: false
    }, providedOptions );

    super( options );

    this.position = options.position;
    this.lensDiameter = options.lensDiameter;

    this.isOnProperty = new BooleanProperty( options.isOn, {
      tandem: options.tandem.createTandem( 'isOnProperty' ),
      phetioFeatured: true
    } );

    this.wavelengthProperty = new NumberProperty( solutionProperty.value.molarAbsorptivityData.lambdaMax /*nm*/, {
      units: 'nm',
      range: BLLConstants.WAVELENGTH_RANGE,
      tandem: options.tandem.createTandem( 'wavelengthProperty' ),
      phetioFeatured: true,
      phetioReadOnly: true
    } );

    this.modeProperty = new EnumerationProperty( LightMode.PRESET, {
      tandem: options.tandem.createTandem( 'modeProperty' ),
      phetioFeatured: true
    } );

    // when the solution changes, set the light to the solution's lambdaMax wavelength
    solutionProperty.link( solution => {
      this.wavelengthProperty.value = solution.molarAbsorptivityData.lambdaMax;
    } );

    this.modeProperty.link( mode => {

      // 'Preset' sets the light to the current solution's lambdaMax wavelength.
      if ( mode === LightMode.PRESET ) {
        this.wavelengthProperty.value = solutionProperty.value.molarAbsorptivityData.lambdaMax;
      }
    } );
  }

  public reset(): void {
    this.isOnProperty.reset();
    this.wavelengthProperty.reset();
    this.modeProperty.reset();
  }

  public getMinY(): number {
    return this.position.y - ( this.lensDiameter / 2 );
  }

  public getMaxY(): number {
    return this.position.y + ( this.lensDiameter / 2 );
  }
}
