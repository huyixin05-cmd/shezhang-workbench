// Copyright 2013-2026, University of Colorado Boulder

/**
 * DetectorNode is the detector for measuring transmittance (%T) and absorbance (A).
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import DerivedProperty from '../../../../axon/js/DerivedProperty.js';
import DerivedStringProperty from '../../../../axon/js/DerivedStringProperty.js';
import Bounds2 from '../../../../dot/js/Bounds2.js';
import Dimension2 from '../../../../dot/js/Dimension2.js';
import Vector2 from '../../../../dot/js/Vector2.js';
import Shape from '../../../../kite/js/Shape.js';
import optionize, { EmptySelfOptions } from '../../../../phet-core/js/optionize.js';
import PickRequired from '../../../../phet-core/js/types/PickRequired.js';
import StringUtils from '../../../../phetcommon/js/util/StringUtils.js';
import ModelViewTransform2 from '../../../../phetcommon/js/view/ModelViewTransform2.js';
import MathSymbols from '../../../../scenery-phet/js/MathSymbols.js';
import PhetFont from '../../../../scenery-phet/js/PhetFont.js';
import ShadedRectangle from '../../../../scenery-phet/js/ShadedRectangle.js';
import VBox from '../../../../scenery/js/layout/nodes/VBox.js';
import Node, { NodeOptions } from '../../../../scenery/js/nodes/Node.js';
import Path from '../../../../scenery/js/nodes/Path.js';
import Text from '../../../../scenery/js/nodes/Text.js';
import BeersLawLabStrings from '../../BeersLawLabStrings.js';
import BLLMovable from '../../common/model/BLLMovable.js';
import Detector from '../model/Detector.js';
import DetectorMode from '../model/DetectorMode.js';
import Light from '../model/Light.js';
import { toFixed } from '../../../../dot/js/util/toFixed.js';
import { linear } from '../../../../dot/js/util/linear.js';
import DetectorModeRadioButtonGroup from './DetectorModeRadioButtonGroup.js';
import { DetectorProbeNode } from './DetectorProbeNode.js';
import BLLColors from '../../common/BLLColors.js';
import Tandem from '../../../../tandem/js/Tandem.js';
import JumpPosition from '../../common/model/JumpPosition.js';
import Property from '../../../../axon/js/Property.js';
import BLLConstants from '../../common/BLLConstants.js';
import { TReadOnlyProperty } from '../../../../axon/js/TReadOnlyProperty.js';

const NO_VALUE = MathSymbols.NO_VALUE;
const BODY_X_MARGIN = 15;
const BODY_Y_MARGIN = 15;
const VALUE_X_MARGIN = 6;
const VALUE_Y_MARGIN = 4;
const MIN_VALUE_SIZE = new Dimension2( 150, 36 );
const MIN_BODY_SIZE = new Dimension2( 185, 140 );

type SelfOptions = EmptySelfOptions;

type DetectorNodeOptions = SelfOptions & PickRequired<NodeOptions, 'tandem'>;

export default class DetectorNode extends Node {

  public constructor( detector: Detector,
                      jumpPositions: JumpPosition[],
                      jumpPositionIndexProperty: Property<number>,
                      light: Light,
                      modelViewTransform: ModelViewTransform2,
                      providedOptions: DetectorNodeOptions ) {

    const options = optionize<DetectorNodeOptions, SelfOptions, NodeOptions>()( {

      // NodeOptions
      isDisposable: false,
      visiblePropertyOptions: {
        phetioFeatured: true
      }
    }, providedOptions );

    super( options );

    const bodyNode = new BodyNode( detector, modelViewTransform, options.tandem.createTandem( 'bodyNode' ) );

    const probeNode = new DetectorProbeNode( detector, jumpPositions, jumpPositionIndexProperty, light,
      modelViewTransform, options.tandem.createTandem( 'probeNode' ) );

    const wireNode = new WireNode( detector.body, detector.probe, bodyNode, probeNode );

    this.children = [ wireNode, bodyNode, probeNode ];

    this.addLinkedElement( detector );

    // Probe gets focus before radio buttons in the body.
    this.pdomOrder = [
      probeNode,
      bodyNode
    ];
  }
}

/**
 * The body of the detector, where A and T values are displayed. Note that while the body is a BLLMovable,
 * we have currently decided not to allow it to be moved, so it has no drag listener.
 */
class BodyNode extends Node {

  public constructor( detector: Detector, modelViewTransform: ModelViewTransform2, tandem: Tandem ) {

    super( {
      accessibleParagraph: createAccessibleParagraph( detector ),
      phetioVisiblePropertyInstrumented: false,
      tandem: tandem
    } );

    // radio button group
    const radioButtonGroup = new DetectorModeRadioButtonGroup( detector, tandem.createTandem( 'radioButtonGroup' ) );

    // value + units
    const valueStringProperty = new DerivedStringProperty(
      [
        BeersLawLabStrings.pattern[ '0percentStringProperty' ],
        detector.modeProperty,
        detector.absorbanceProperty,
        detector.transmittanceProperty
      ],
      ( pattern, mode, absorbance, transmittance ) => {
        let valueString: string;
        if ( mode === DetectorMode.TRANSMITTANCE ) {
          valueString = ( transmittance === null ) ?
                        NO_VALUE :
                        StringUtils.format( pattern, toFixed( 100 * transmittance, BLLConstants.DECIMAL_PLACES_TRANSMITTANCE ) );
        }
        else {
          valueString = ( absorbance === null ) ? NO_VALUE : toFixed( absorbance, BLLConstants.DECIMAL_PLACES_ABSORBANCE );
        }
        return valueString;
      }, {
        tandem: tandem.createTandem( 'valueStringProperty' ),
        phetioFeatured: true
      } );

    const valueText = new Text( valueStringProperty, {
      font: new PhetFont( 22 ),
      maxWidth: 125
    } );

    // background behind the value
    const backgroundWidth = Math.max( MIN_VALUE_SIZE.width, Math.max( radioButtonGroup.width, valueText.width ) + ( 2 * VALUE_X_MARGIN ) );
    const backgroundHeight = Math.max( MIN_VALUE_SIZE.height, valueText.height + ( 2 * VALUE_Y_MARGIN ) );
    const backgroundNode = new ShadedRectangle( new Bounds2( 0, 0, backgroundWidth, backgroundHeight ), {
      baseColor: 'white',
      lightSource: 'rightBottom'
    } );

    // vertical arrangement of stuff in the meter
    const vBox = new VBox( {
      children: [ new Node( { children: [ backgroundNode, valueText ] } ), radioButtonGroup ],
      align: 'left',
      spacing: 12
    } );

    // meter body
    const bodyWidth = Math.max( MIN_BODY_SIZE.width, vBox.width + ( 2 * BODY_X_MARGIN ) );
    const bodyHeight = Math.max( MIN_BODY_SIZE.height, vBox.height + ( 2 * BODY_Y_MARGIN ) );
    const bodyNode = new ShadedRectangle( new Bounds2( 0, 0, bodyWidth, bodyHeight ), {
      baseColor: BLLColors.atDetectorColorProperty,
      lightOffset: 0.95
    } );

    vBox.boundsProperty.link( bounds => {
      vBox.center = bodyNode.center;
    } );

    this.children = [ bodyNode, vBox ];

    // body position
    detector.body.positionProperty.link( ( position: Vector2 ) => {
      this.translation = modelViewTransform.modelToViewPosition( position );
    } );

    valueText.boundsProperty.link( bounds => {
      if ( valueStringProperty.value === NO_VALUE ) {
        // centered
        valueText.centerX = backgroundNode.centerX;
      }
      else {
        // right justified
        valueText.right = backgroundNode.right - VALUE_X_MARGIN;
      }
      valueText.centerY = backgroundNode.centerY;
    } );
  }
}

/**
 * Wire that connects the body and probe
 */
class WireNode extends Path {

  public constructor( body: BLLMovable, probe: BLLMovable, bodyNode: Node, probeNode: Node ) {

    const shapeProperty = new DerivedProperty( [
      body.positionProperty,
      probe.positionProperty
    ], () => {
      // connection points
      const bodyConnectionPoint = new Vector2( bodyNode.centerX, bodyNode.bottom );
      const probeConnectionPoint = new Vector2( probeNode.centerX, probeNode.bottom );

      // control points
      // The y coordinate of the body's control point varies with the x distance between the body and probe.
      const c1Offset = new Vector2( 0, linear( 0, 800, 0, 200, bodyNode.centerX - probeNode.left ) ); // x distance -> y coordinate
      const c2Offset = new Vector2( 50, 150 );
      const c1 = new Vector2( bodyConnectionPoint.x + c1Offset.x, bodyConnectionPoint.y + c1Offset.y );
      const c2 = new Vector2( probeConnectionPoint.x + c2Offset.x, probeConnectionPoint.y + c2Offset.y );

      // cubic curve
      return new Shape()
        .moveTo( bodyConnectionPoint.x, bodyConnectionPoint.y )
        .cubicCurveTo( c1.x, c1.y, c2.x, c2.y, probeConnectionPoint.x, probeConnectionPoint.y );
    } );

    super( shapeProperty, {

      // PathOptions
      stroke: 'gray',
      lineWidth: 8,
      lineCap: 'square',
      lineJoin: 'round',
      pickable: false
    } );
  }
}

/**
 * Creates the accessible paragraph for DetectorNode.BodyNode.
 */
function createAccessibleParagraph( detector: Detector ): TReadOnlyProperty<string> {
  return new DerivedStringProperty( [
    detector.modeProperty,
    detector.transmittanceProperty,
    detector.absorbanceProperty,

    // Localized strings used in this derivation.
    BeersLawLabStrings.a11y.transmittanceValueUnitsStringProperty,
    BeersLawLabStrings.a11y.transmittanceUnknownStringProperty,
    BeersLawLabStrings.a11y.absorbanceValueStringProperty,
    BeersLawLabStrings.a11y.absorbanceUnknownStringProperty,
    BeersLawLabStrings.a11y.unitsDescription.percentStringProperty
  ], ( mode, transmittance, absorbance ) => {
    if ( mode === DetectorMode.TRANSMITTANCE ) {
      if ( transmittance === null ) {
        return BeersLawLabStrings.a11y.transmittanceUnknownStringProperty.value;
      }
      else {
        return StringUtils.fillIn( BeersLawLabStrings.a11y.transmittanceValueUnitsStringProperty.value, {
          transmittance: toFixed( 100 * transmittance, BLLConstants.DECIMAL_PLACES_TRANSMITTANCE ),
          units: BeersLawLabStrings.a11y.unitsDescription.percentStringProperty.value
        } );
      }
    }
    else {
      assert && assert( mode === DetectorMode.ABSORBANCE );
      if ( absorbance === null ) {
        return BeersLawLabStrings.a11y.absorbanceUnknownStringProperty.value;
      }
      else {
        return StringUtils.fillIn( BeersLawLabStrings.a11y.absorbanceValueStringProperty.value, {
          absorbance: toFixed( absorbance, BLLConstants.DECIMAL_PLACES_ABSORBANCE )
        } );
      }
    }
  }, {
    isDisposable: false
  } );
}
