/*
 * Copyright 2026 The Ray Optics Simulation authors and contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import PrimitiveBasedSimulator from '../../src/core/PrimitiveBasedSimulator';
import { FLOAT32_EPSILON } from '../../src/core/primitive/numeric';
import {
  INTERSECTION_CONFLICT_MERGE,
  INTERSECTION_CONFLICT_NORMAL,
  INTERSECTION_CONFLICT_ORIENTATION
} from '../../src/core/primitive/interactionCandidate';
import i18next from 'i18next';
import Detector from '../../src/core/sceneObjs/other/Detector.js';

function createScene() {
  return {
    lengthScale: 1,
    origin: { x: 0, y: 0 },
    scale: 1,
    rayPowerCutoff: 1e-6,
    rayPowerSampling: false,
    colorMode: 'default',
    mode: 'rays',
    simulateColors: false,
    keepNonVisibleLight: false,
    showRayArrows: false,
    observer: null,
    opticalObjs: []
  };
}

describe('PrimitiveBasedSimulator wavelength colors', () => {
  it('only clamps non-visible colors when the option is enabled', () => {
    const simulator = createSimulator('primitiveCpu');

    expect(simulator.wavelengthToColor(300, 1, false))
      .toEqual([0, 0, 0, 1]);
    expect(simulator.wavelengthToColor(800, 1, false))
      .toEqual([0, 0, 0, 1]);

    simulator.scene.keepNonVisibleLight = true;
    expect(simulator.wavelengthToColor(300, 1, false))
      .toEqual([0.125, 0, 0.25, 1]);
    expect(simulator.wavelengthToColor(800, 1, false))
      .toEqual([0.25, 0, 0, 1]);
    expect(simulator.wavelengthToColor(0, 1, false))
      .toEqual([0, 0, 0, 1]);
    expect(simulator.wavelengthToColor(Infinity, 1, false))
      .toEqual([0, 0, 0, 1]);
  });
});

function createSimulator(engineKind) {
  return new PrimitiveBasedSimulator({
    scene: createScene(),
    engine: {
      kind: engineKind,
      numericEpsilon: FLOAT32_EPSILON
    }
  });
}

function createProviderEngine(kind) {
  return {
    kind,
    numericEpsilon: kind === 'webgpu' ? FLOAT32_EPSILON : Number.EPSILON,
    dispose: jest.fn()
  };
}

describe('PrimitiveBasedSimulator engine registry', () => {
  it('lazily creates and retains engines when selection changes', () => {
    const cpu = createProviderEngine('primitiveCpu');
    const gpu = createProviderEngine('webgpu');
    const createCpu = jest.fn(() => cpu);
    const createGpu = jest.fn(() => gpu);
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: createCpu,
        webgpu: createGpu
      }
    });

    expect(simulator.engine).toBe(cpu);
    expect(createCpu).toHaveBeenCalledTimes(1);
    expect(createGpu).not.toHaveBeenCalled();

    simulator.activateEngine('webgpu');
    simulator.activateEngine('primitiveCpu');
    simulator.activateEngine('webgpu');

    expect(createCpu).toHaveBeenCalledTimes(1);
    expect(createGpu).toHaveBeenCalledTimes(1);
    expect(cpu.dispose).not.toHaveBeenCalled();
    simulator.destroy();
    expect(cpu.dispose).toHaveBeenCalledTimes(1);
    expect(gpu.dispose).toHaveBeenCalledTimes(1);
  });

  it('restarts a failed WebGPU scene revision on CPU', async () => {
    const cpu = createProviderEngine('primitiveCpu');
    const gpu = createProviderEngine('webgpu');
    const engineChanges = [];
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'webgpu',
      engineProviders: {
        primitiveCpu: () => cpu,
        webgpu: () => gpu
      }
    });
    simulator.on('engineChange', event => engineChanges.push(event));
    simulator.runEngine = jest.fn()
      .mockRejectedValueOnce(new Error('storage limit'))
      .mockResolvedValueOnce(undefined);

    await simulator.startEngineRun(0);

    expect(simulator.runEngine).toHaveBeenCalledTimes(2);
    expect(simulator.engine).toBe(cpu);
    expect(simulator.engineFallbackActive).toBe(true);
    // The visible canvas remains on the previous completed frame until the
    // fallback engine publishes its first current-revision update.
    expect(engineChanges).toEqual([]);
    expect(simulator.engineFallbackWarning).toBeTruthy();
    expect(gpu.dispose).not.toHaveBeenCalled();
  });

  it('uses a measured winner regardless of the formula score', () => {
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.automaticEngineWinner = 'primitiveCpu';

    expect(simulator.selectEngineKind({
      initialRayCount: 1024,
      primitiveCurveCount: 1
    })).toBe('primitiveCpu');
    expect(simulator.selectEngineKind({
      initialRayCount: 10241,
      primitiveCurveCount: 1
    })).toBe('primitiveCpu');

    simulator.automaticEngineWinner = null;
    expect(simulator.selectEngineKind({
      initialRayCount: 10241,
      primitiveCurveCount: 1
    })).toBe('webgpu');
    expect(simulator.getEngineSelectionDecision({
      initialRayCount: 1,
      primitiveCurveCount: 1
    }).comparisonEligible).toBe(true);
    expect(simulator.getEngineSelectionDecision({
      initialRayCount: 1000000,
      primitiveCurveCount: 1000000
    }).comparisonEligible).toBe(true);
  });

  it('starts positive-step GRIN workloads on WebGPU despite a CPU winner',
    () => {
      const simulator = new PrimitiveBasedSimulator({
        scene: createScene(),
        enginePreference: 'automatic',
        engineProviders: {
          primitiveCpu: () => createProviderEngine('primitiveCpu'),
          webgpu: () => createProviderEngine('webgpu')
        }
      });
      simulator.automaticEngineWinner = 'primitiveCpu';

      const decision = simulator.getEngineSelectionDecision({
        initialRayCount: 1,
        primitiveCurveCount: 1,
        hasGrinRegion: true
      });

      expect(decision.selectedEngineKind).toBe('webgpu');
      expect(decision.learnedEngineKind).toBe('primitiveCpu');
      expect(decision.reason).toBe('grin-region');
    });

  it('uses the same default-color cutoff and sampling mode for both engines', () => {
    const scene = createScene();
    const simulator = new PrimitiveBasedSimulator({
      scene,
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });

    expect(simulator.createRunJob(0).sceneOptions).toMatchObject({
      rayPowerCutoff: 0.01,
      rayPowerSampling: true
    });

    scene.rayPowerCutoff = 0.02;
    expect(simulator.createRunJob(0).sceneOptions).toMatchObject({
      rayPowerCutoff: 0.01,
      rayPowerSampling: true
    });

    scene.colorMode = 'linear';
    scene.rayPowerCutoff = 1e-6;
    scene.rayPowerSampling = false;
    expect(simulator.createRunJob(0).sceneOptions).toMatchObject({
      rayPowerCutoff: 1e-6,
      rayPowerSampling: false
    });
  });

  it('passes the non-visible-light option into engine preparation',
    async () => {
      const simulator = createSimulator('primitiveCpu');
      simulator.scene.keepNonVisibleLight = true;
      const run = {
        advance: jest.fn(async () => ({
          status: 'complete',
          progress: { processedRayCount: 0, totalTruncation: 0 },
          result: { detectors: [] }
        })),
        dispose: jest.fn()
      };
      simulator.engine.prepare = jest.fn(async description => ({
        description
      }));
      simulator.engine.createRun = jest.fn(async () => run);
      simulator.updateSimulation = jest.fn();

      await simulator.runEngine(0);

      expect(simulator.engine.prepare).toHaveBeenCalledWith(
        simulator.processedScene,
        expect.objectContaining({ keepNonVisibleLight: true })
      );
    });

  it('does not expose an engine canvas until its current frame is published', () => {
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    const changes = [];
    simulator.on('engineChange', event => changes.push(event));

    simulator.activateEngine('webgpu', { deferPresentation: true });
    expect(changes).toEqual([]);
    simulator.presentEngine('webgpu');

    expect(changes).toEqual([
      expect.objectContaining({
        kind: 'webgpu',
        previousKind: 'primitiveCpu'
      })
    ]);
  });

  it('records a faster silent challenger for the next scene update', async () => {
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.workload = { initialRayCount: 512, primitiveCurveCount: 1 };
    const firstJob = simulator.createRunJob(0);
    simulator.runEngine = jest.fn(async job => ({
      completed: true,
      job,
      durationMs: 75
    }));

    await simulator.runAutomaticComparison(firstJob, 150, 'webgpu');

    expect(simulator.automaticEngineWinner).toBe('webgpu');
    expect(simulator.selectEngineKind(simulator.workload)).toBe('webgpu');
  });

  it('always schedules CPU after WebGPU, even when WebGPU is fast', () => {
    jest.useFakeTimers();
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.activateEngine('webgpu');
    const webGpuJob = simulator.createRunJob(0);
    const queueComparison = jest.spyOn(
      simulator,
      'queueAutomaticComparison'
    ).mockImplementation(() => {});

    simulator.scheduleAutomaticComparison(webGpuJob, 5);
    jest.runAllTimers();

    expect(queueComparison).toHaveBeenCalledWith(
      webGpuJob,
      5,
      'primitiveCpu'
    );

    queueComparison.mockClear();
    simulator.activateEngine('primitiveCpu');
    simulator.scheduleAutomaticComparison(simulator.createRunJob(0), 5);
    jest.runAllTimers();
    expect(queueComparison).not.toHaveBeenCalled();
    jest.useRealTimers();
  });

  it('does not challenge an explicitly selected WebGPU with CPU', () => {
    jest.useFakeTimers();
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'webgpu',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    const webGpuJob = simulator.createRunJob(0);
    expect(webGpuJob.comparisonEligible).toBe(false);
    const queueComparison = jest.spyOn(
      simulator,
      'queueAutomaticComparison'
    ).mockImplementation(() => {});
    simulator.scheduleAutomaticComparison(webGpuJob, 6.1);
    jest.runAllTimers();

    expect(queueComparison).not.toHaveBeenCalled();
    jest.useRealTimers();
  });

  it('does not challenge an explicitly selected CPU with WebGPU', () => {
    jest.useFakeTimers();
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'primitiveCpu',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    const queueComparison = jest.spyOn(
      simulator,
      'queueAutomaticComparison'
    ).mockImplementation(() => {});

    simulator.scheduleAutomaticComparison(simulator.createRunJob(0), 150);
    jest.runAllTimers();

    expect(queueComparison).not.toHaveBeenCalled();
    jest.useRealTimers();
  });

  it('prefers a sub-20ms CPU challenger even when WebGPU is faster', async () => {
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.activateEngine('webgpu');
    const firstJob = simulator.createRunJob(0);
    simulator.runEngine = jest.fn(async job => ({
      completed: true,
      job,
      durationMs: 15
    }));
    await simulator.runAutomaticComparison(
      firstJob,
      5,
      'primitiveCpu'
    );

    expect(simulator.runEngine).toHaveBeenCalledWith(
      expect.objectContaining({ engineKind: 'primitiveCpu' }),
      { silent: true, timeLimitMs: 20 }
    );
    expect(simulator.automaticEngineWinner).toBe('primitiveCpu');
  });

  it.each([
    ['webgpu', 'primitiveCpu'],
    ['primitiveCpu', 'webgpu']
  ])(
    'keeps forced %s despite a stale learned winner',
    (enginePreference, staleWinner) => {
      const simulator = new PrimitiveBasedSimulator({
        scene: createScene(),
        enginePreference,
        engineProviders: {
          primitiveCpu: () => createProviderEngine('primitiveCpu'),
          webgpu: () => createProviderEngine('webgpu')
        }
      });
      simulator.automaticEngineWinner = staleWinner;

      expect(simulator.selectEngineKind(simulator.workload))
        .toBe(enginePreference);
      simulator.collectAndPreprocessPrimitives();
      expect(simulator.engine.kind).toBe(enginePreference);
      expect(simulator.createRunJob(70).comparisonEligible).toBe(false);
    }
  );

  it('clears a comparison winner when the user changes preference', () => {
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'webgpu',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.automaticEngineWinner = 'primitiveCpu';

    simulator.setEnginePreference('automatic');

    expect(simulator.automaticEngineWinner).toBeNull();
  });

  it('stops preferring CPU once its comparison reaches 20ms', async () => {
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.activateEngine('webgpu');
    const firstJob = simulator.createRunJob(0);
    simulator.runEngine = jest.fn(async job => ({
      completed: false,
      slower: true,
      job,
      durationMs: 20
    }));

    await simulator.runAutomaticComparison(
      firstJob,
      5,
      'primitiveCpu'
    );

    expect(simulator.automaticEngineWinner).toBe('webgpu');
  });

  it('cancels a scheduled silent comparison when the scene changes', () => {
    jest.useFakeTimers();
    const simulator = new PrimitiveBasedSimulator({
      scene: createScene(),
      enginePreference: 'automatic',
      engineProviders: {
        primitiveCpu: () => createProviderEngine('primitiveCpu'),
        webgpu: () => createProviderEngine('webgpu')
      }
    });
    simulator.workload = { initialRayCount: 1024, primitiveCurveCount: 1 };
    const job = simulator.createRunJob(0);
    simulator.runAutomaticComparison = jest.fn();

    simulator.scheduleAutomaticComparison(job, 51);
    simulator.cancelObsoleteWork();
    jest.runAllTimers();

    expect(simulator.runAutomaticComparison).not.toHaveBeenCalled();
    jest.useRealTimers();
  });

  it('keeps silent-run progress, detectors, and status unpublished', async () => {
    const simulator = createSimulator('primitiveCpu');
    const silentEngine = createProviderEngine('primitiveCpu');
    const run = {
      advance: jest.fn(async () => ({
        status: 'complete',
        progress: { processedRayCount: 99, totalTruncation: 0.5 },
        result: { detectors: [Float64Array.of(7)] }
      })),
      dispose: jest.fn()
    };
    silentEngine.prepare = jest.fn(async description => ({ description }));
    silentEngine.createRun = jest.fn(async () => run);
    const binding = { resultId: 0, result: { values: null } };
    const job = simulator.createRunJob(0, {
      engine: silentEngine,
      detectorResultBindings: [binding]
    });
    simulator.publishRunUpdate = jest.fn();
    simulator.updateSimulation = jest.fn();
    const simulationEvents = [];
    simulator.on('simulationPause', () => simulationEvents.push('pause'));
    simulator.on('simulationComplete', () => simulationEvents.push('complete'));

    const result = await simulator.runEngine(job, {
      silent: true,
      timeLimitMs: 1000
    });

    expect(result.completed).toBe(true);
    expect(simulator.publishRunUpdate).not.toHaveBeenCalled();
    expect(simulator.updateSimulation).not.toHaveBeenCalled();
    expect(binding.result.values).toBeNull();
    expect(simulationEvents).toEqual([]);
  });
});

describe('PrimitiveBasedSimulator run results', () => {
  it('publishes completed detector arrays through their result bindings', async () => {
    const simulator = createSimulator('primitiveCpu');
    const result = { values: null };
    simulator.detectorResultBindings = [{
      resultId: 0,
      result,
      resultSize: 2
    }];
    simulator.scene.origin = { x: 0, y: 0 };
    simulator.scene.scale = 1;
    simulator.scene.colorMode = 'default';
    simulator.scene.mode = 'rays';
    simulator.scene.simulateColors = false;
    simulator.scene.showRayArrows = false;
    simulator.scene.observer = null;
    const run = {
      advance: jest.fn(async () => ({
        status: 'complete',
        progress: {
          processedRayCount: 1,
          totalTruncation: 0
        },
        result: {
          detectors: [Float64Array.of(2, 3)]
        }
      })),
      dispose: jest.fn()
    };
    simulator.engine.prepare = jest.fn(async description => ({
      description
    }));
    simulator.engine.createRun = jest.fn(async () => run);
    simulator.updateSimulation = jest.fn();

    await simulator.runEngine(0);

    expect(simulator.engine.createRun).toHaveBeenCalledWith(
      expect.objectContaining({
        rayPowerCutoff: 0.01,
        rayPowerSampling: true
      })
    );
    expect(result.values).toEqual(Float64Array.of(2, 3));
    expect(simulator.updateSimulation).toHaveBeenCalledWith(true, true);
    expect(run.dispose).toHaveBeenCalled();
  });

  it('publishes progress and detector readings on every paused update', async () => {
    const simulator = createSimulator('primitiveCpu');
    simulator.enableTimer = true;
    const result = { values: null };
    simulator.detectorResultBindings = [{
      resultId: 0,
      result,
      resultSize: 1
    }];
    simulator.scene.origin = { x: 0, y: 0 };
    simulator.scene.scale = 1;
    simulator.scene.colorMode = 'default';
    simulator.scene.mode = 'rays';
    simulator.scene.simulateColors = false;
    simulator.scene.showRayArrows = false;
    simulator.scene.observer = null;
    const updates = [{
      status: 'running',
      progress: {
        processedRayCount: 4,
        totalTruncation: 0.25
      },
      result: {
        detectors: [Float64Array.of(2)]
      }
    }, {
      status: 'complete',
      progress: {
        processedRayCount: 7,
        totalTruncation: 0.5
      },
      result: {
        detectors: [Float64Array.of(3)]
      }
    }];
    const run = {
      advance: jest.fn(async () => updates.shift()),
      dispose: jest.fn()
    };
    simulator.engine.prepare = jest.fn(async description => ({
      description
    }));
    simulator.engine.createRun = jest.fn(async () => run);
    simulator.updateSimulation = jest.fn();
    const pauseSnapshots = [];
    simulator.on('simulationPause', () => {
      pauseSnapshots.push({
        processedRayCount: simulator.processedRayCount,
        totalTruncation: simulator.totalTruncation,
        brightnessScale: simulator.brightnessScale,
        detectorValues: Array.from(result.values)
      });
    });

    await simulator.runEngine(0);

    expect(pauseSnapshots).toEqual([{
      processedRayCount: 4,
      totalTruncation: 0.25,
      brightnessScale: 0,
      detectorValues: [2]
    }]);
    expect(simulator.updateSimulation).toHaveBeenNthCalledWith(
      1,
      true,
      true
    );
    expect(simulator.updateSimulation).toHaveBeenNthCalledWith(
      2,
      true,
      true
    );
    expect(result.values).toEqual(Float64Array.of(3));
    expect(simulator.processedRayCount).toBe(7);
    expect(simulator.totalTruncation).toBe(0.5);
    expect(simulator.brightnessScale).toBe(0);
  });

  it('reports a consistent mapped brightness scale to simulator status', () => {
    const simulator = createSimulator('primitiveCpu');
    simulator.scene.opticalObjs = [
      createMappedObject('PointSource', 0.5),
      createMappedObject('Beam', 0.5)
    ];

    simulator.collectAndPreprocessPrimitives();

    expect(simulator.brightnessScale).toBe(0.5);
    expect(simulator.warning).toBeNull();
  });

  it('reports the legacy inconsistent-brightness warning after mapping', () => {
    const simulator = createSimulator('primitiveCpu');
    simulator.scene.opticalObjs = [
      createMappedObject('PointSource', 0.5),
      createMappedObject('Beam', 0.25),
      createDetector(simulator.scene)
    ];

    simulator.collectAndPreprocessPrimitives();

    expect(simulator.brightnessScale).toBe(-1);
    expect(simulator.warning).toBe(
      i18next.t('simulator:generalWarnings.brightnessInconsistent')
    );
  });

  it('does not count a Detector object which produces no detector primitive', () => {
    const simulator = createSimulator('primitiveCpu');
    simulator.scene.opticalObjs = [
      createMappedObject('PointSource', 0.5),
      createMappedObject('Beam', 0.25),
      createMappedObject('Detector', null)
    ];

    simulator.collectAndPreprocessPrimitives();

    expect(simulator.brightnessScale).toBe(-1);
    expect(simulator.warning).toBeNull();
  });

  it('ignores mapped brightness scales outside legacy color mode', () => {
    const simulator = createSimulator('primitiveCpu');
    simulator.scene.colorMode = 'linear';
    simulator.scene.opticalObjs = [
      createMappedObject('PointSource', 0.5),
      createMappedObject('Beam', 0.25)
    ];

    simulator.collectAndPreprocessPrimitives();

    expect(simulator.brightnessScale).toBe(0);
    expect(simulator.warning).toBeNull();
  });
});

describe('PrimitiveBasedSimulator engine warnings', () => {
  it('surfaces a structured tolerance warning', () => {
    const simulator = createSimulator('primitiveCpu');

    simulator.publishRunUpdate({
      progress: {},
      result: {
        warning: {
          type: INTERSECTION_CONFLICT_MERGE,
          rayIndex: 3,
          curveId: 4,
          conflictingCurveId: 7,
          tolerance: {
            kind: 'interactionMerging',
            unit: 'sceneUnits',
            value: 2e-4
          }
        }
      }
    });

    expect(simulator.engineWarning.tolerance).toEqual({
      kind: 'interactionMerging',
      unit: 'sceneUnits',
      value: 2e-4
    });
    expect(simulator.warning).toBe(
      '{{simulator:generalWarnings.primitiveMergeConflict}}'
    );
  });

  it('marks curve IDs with namespaced diagnostic references', () => {
    const simulator = createSimulator('primitiveCpu');
    const originalTranslate = i18next.t;
    i18next.t = (key, options = {}) => {
      if (key === 'simulator:generalWarnings.primitiveMergeConflict') {
        return `curves ${options.curveId} and ${options.conflictingCurveId}`;
      }
      return `{{${key}}}`;
    };

    try {
      simulator.publishRunUpdate({
        progress: {},
        result: {
          warning: {
            type: INTERSECTION_CONFLICT_MERGE,
            rayIndex: 3,
            curveId: 4,
            conflictingCurveId: 7,
            tolerance: {
              kind: 'interactionMerging',
              unit: 'sceneUnits',
              value: 2e-4
            }
          }
        }
      });

      expect(simulator.warning).toBe(
        'curves ⟦pc:4⟧ and ⟦pc:7⟧'
      );
    } finally {
      i18next.t = originalTranslate;
    }
  });

  it.each([
    [INTERSECTION_CONFLICT_MERGE, 'primitiveMergeConflict'],
    [INTERSECTION_CONFLICT_ORIENTATION, 'primitiveOrientationConflict'],
    [INTERSECTION_CONFLICT_NORMAL, 'primitiveNormalConflict']
  ])('shows a concise conflict label for type %s', (type, label) => {
    const simulator = createSimulator('primitiveCpu');
    const originalTranslate = i18next.t;
    i18next.t = (key, options = {}) => {
      if (key === `simulator:generalWarnings.${label}`) {
        expect(options).toEqual({
          curveId: '⟦pc:4⟧',
          conflictingCurveId: '⟦pc:7⟧'
        });
        return label;
      }
      return `{{${key}}}`;
    };

    try {
      simulator.publishRunUpdate({
        progress: {},
        result: {
          warning: {
            type,
            rayIndex: 3,
            curveId: 4,
            conflictingCurveId: 7,
            ambiguousPower: 0.00125,
            tolerance: {
              kind: 'interactionMerging',
              unit: 'sceneUnits',
              value: 2e-4
            }
          }
        }
      });

      expect(simulator.warning).toBe(label);
    } finally {
      i18next.t = originalTranslate;
    }
  });
});

function createMappedObject(type, brightnessScale) {
  return {
    brightnessScale: null,
    constructor: { type },
    getPrimitives() {
      this.brightnessScale = brightnessScale;
      return [];
    }
  };
}

function createDetector(scene) {
  const detector = new Detector(scene);
  detector.p1 = { x: 0, y: 0 };
  detector.p2 = { x: 10, y: 0 };
  return detector;
}
