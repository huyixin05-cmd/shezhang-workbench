<!--
  Copyright 2025 The Ray Optics Simulation authors and contributors

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
-->

<template>
  <div 
    class="row settings-control-row d-flex justify-content-between align-items-center"
    v-tooltip-popover:[tooltipType]="layout === 'desktop' && popoverContent ? { 
      content: popoverContent,
      html: true,
      placement: 'left',
      offset: [verticalOffset, 20]
    } : undefined"
  >
    <div class="col-auto settings-label" v-html="label"></div>
    <div class="col-auto d-flex align-items-center">
      <div class="flex-grow-1 d-flex align-items-center">
        <input 
          type="text" 
          class="settings-number" 
          :class="{ 'settings-control-value--disabled': disabled }"
          v-model="inputValue"
          :disabled="disabled"
          @keyup.enter="handleEnter"
          @keydown="handleKeydown"
          @blur="handleBlur"
          @click="!disabled && $event.target.select()"
        >
      </div>
    </div>
  </div>
</template>

<script>
/**
 * @module NumberControl
 * @description The vue component for a number control in the setting dropdown.
 * @vue-prop {String} label - The label for the number control.
 * @vue-prop {Number} modelValue - The current value of the number control.
 * @vue-prop {String} layout - The layout of the control. Can be 'mobile' or 'desktop'.
 * @vue-prop {String} [popoverContent=''] - The content of the popover.
 * @vue-prop {Number} [verticalOffset=0] - The vertical offset of the popover.
 * @vue-prop {Number} [min=null] - The minimum value of the number control.
 * @vue-prop {Number} [max=null] - The maximum value of the number control.
 * @vue-prop {Number} [defaultValue=null] - The default value of the number control.
 * @vue-prop {Boolean} [disabled=false] - If true, the value is read-only and visually de-emphasized.
 */
import { computed, toRef, ref, watch } from 'vue'
import { vTooltipPopover } from '../../../directives/tooltip-popover'
import { usePreferencesStore } from '../../../store/preferences'

export default {
  name: 'NumberControl',
  directives: {
    'tooltip-popover': vTooltipPopover
  },
  props: {
    label: {
      type: String,
      required: true
    },
    modelValue: {
      type: Number,
      required: true
    },
    layout: {
      type: String,
      required: true
    },
    popoverContent: {
      type: String,
      default: ''
    },
    verticalOffset: {
      type: Number,
      default: 0
    },
    min: {
      type: Number,
      default: null
    },
    max: {
      type: Number,
      default: null
    },
    defaultValue: {
      type: Number,
      default: null
    },
    disabled: {
      type: Boolean,
      default: false
    }
  },
  setup(props, { emit }) {
    const preferences = usePreferencesStore()
    const help = toRef(preferences, 'help')
    const tooltipType = computed(() => help.value ? 'popover' : null)

    const numberToDisplayString = (num) => {
      if (num === Infinity) return 'inf'
      if (num === -Infinity) return '-inf'
      if (num == null) return ''
      const decimal = num.toString()
      if (num === 0 || !Number.isFinite(num)) return decimal
      const scientific = num.toExponential().replace('e+', 'e')
      return scientific.length < decimal.length ? scientific : decimal
    }

    const displayStringToNumber = (str) => {
      const s = (str ?? '').toString().trim().toLowerCase()
      if (s.startsWith('-inf')) return -Infinity
      if (s.startsWith('inf')) return Infinity
      return parseFloat(str)
    }
    
    // Create a local input value ref
    const inputValue = ref(numberToDisplayString(props.modelValue))

    // Watch for external changes to modelValue
    watch(() => props.modelValue, (newVal) => {
      inputValue.value = numberToDisplayString(newVal)
    })

    const validateAndEmit = (value) => {
      // Handle empty or invalid input
      const parsed = displayStringToNumber(value)
      if (value === '' || Number.isNaN(parsed)) {
        const defaultVal = props.defaultValue !== null ? props.defaultValue : 0
        inputValue.value = numberToDisplayString(defaultVal)
        emit('update:modelValue', defaultVal)
        return
      }

      let numValue = parsed

      // Apply min/max constraints
      if (props.min !== null && numValue < props.min) {
        numValue = props.min
      }
      if (props.max !== null && numValue > props.max) {
        numValue = props.max
      }

      // Update both local value and emit change
      inputValue.value = numberToDisplayString(numValue)
      emit('update:modelValue', numValue)
    }

    return {
      tooltipType,
      inputValue,
      validateAndEmit
    }
  },
  methods: {
    handleKeydown(e) {
      e.stopPropagation()
    },
    handleEnter(e) {
      if (this.disabled) return
      this.validateAndEmit(e.target.value)
      e.target.select() // Re-select the text after validation
    },
    handleBlur(e) {
      if (this.disabled) return
      this.validateAndEmit(e.target.value)
    }
  },
  emits: ['update:modelValue']
}
</script>

<style scoped>
.settings-number {
  background-color: transparent;
  border: none;
  border-bottom: 1px solid rgba(0, 0, 0, 0.5);
  width: 40px;
  height: 23px;
  text-align: center;
  margin-right: 4px;
}

</style>
