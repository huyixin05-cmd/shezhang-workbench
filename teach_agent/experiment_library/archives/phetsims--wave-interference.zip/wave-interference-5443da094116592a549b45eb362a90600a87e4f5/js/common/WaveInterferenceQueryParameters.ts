// Copyright 2018-2026, University of Colorado Boulder

/**
 * Query parameters used in sim-specific code.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import { QueryStringMachine } from '../../../query-string-machine/js/QueryStringMachineModule.js';

const WaveInterferenceQueryParameters = QueryStringMachine.getAll( {

  // Shows the overlays for the theoretical/ideal (far-field) interference patterns on the "Slits" screen. Starting in
  // 1.1+, this will be shared with teachers and should not be changed lightly.
  // See https://github.com/phetsims/wave-interference/issues/196
  theory: { type: 'flag', public: true },

  latticeSize: { type: 'number', defaultValue: 151 }
} );

export default WaveInterferenceQueryParameters;
