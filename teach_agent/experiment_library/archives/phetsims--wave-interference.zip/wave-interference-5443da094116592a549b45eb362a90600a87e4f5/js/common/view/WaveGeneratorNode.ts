// Copyright 2018-2026, University of Colorado Boulder
/**
 * For each scene, shows one node for each wave generator, each with its own on/off button.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import ShadedSphereNode from '../../../../scenery-phet/js/ShadedSphereNode.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import RoundStickyToggleButton from '../../../../sun/js/buttons/RoundStickyToggleButton.js';
import Scene from '../model/Scene.js';
import WaterScene from '../model/WaterScene.js';
import WaveInterferenceConstants from '../WaveInterferenceConstants.js';
import DisturbanceTypeIconNode from './DisturbanceTypeIconNode.js';
import WaveAreaNode from './WaveAreaNode.js';

class WaveGeneratorNode extends Node {

  /**
   * @param scene
   * @param waveAreaNode - for bounds
   * @param buttonPosition - x offset
   * @param isPrimarySource
   * @param sourceNode - for the wave generators, shared with scenery DAG
   * @param [verticalOffset] - offset for the hose, so the water has some distance to fall
   * @param [buttonOffset] - offset for the button, so it can be positioned on the pipe
   * @param [showButtonBackground] - true if a new background for the button should be added
   */
  public constructor( scene: Scene, waveAreaNode: WaveAreaNode, buttonPosition: number, isPrimarySource: boolean, sourceNode: Node,
                      verticalOffset = 0,
                      buttonOffset = 0,
                      showButtonBackground = false ) {

    const pulseIcon = new DisturbanceTypeIconNode( 'pulse', {
      scale: 0.36,
      stroked: true
    } );

    const buttonPressedProperty = isPrimarySource ? scene.button1PressedProperty : scene.button2PressedProperty;

    // Adapters to play the waveGeneratorButtonSound for the scene's unpressed/pressed states.
    const valueUpSoundPlayer = {
      play() {
        scene.waveGeneratorButtonSound( false );
      },
      stop() {
        // nothing to stop
      }
    };
    const valueDownSoundPlayer = {
      play() {
        scene.waveGeneratorButtonSound( true );
      },
      stop() {
        // nothing to stop
      }
    };

    const buttonOptions = {
      centerY: sourceNode.centerY + buttonOffset,
      left: buttonPosition,
      radius: WaveInterferenceConstants.WAVE_GENERATOR_BUTTON_RADIUS,
      content: pulseIcon,
      touchAreaDilation: WaveInterferenceConstants.WAVE_GENERATOR_BUTTON_TOUCH_AREA_DILATION,
      baseColor: WaveInterferenceConstants.WAVE_GENERATOR_BUTTON_COLOR,
      valueUpSoundPlayer: valueUpSoundPlayer,
      valueDownSoundPlayer: valueDownSoundPlayer
    };

    const button = new RoundStickyToggleButton( buttonPressedProperty, false, true, buttonOptions );
    const children = [ sourceNode ];
    if ( showButtonBackground ) {
      const diameter = button.width * 1.3;
      children.push( new ShadedSphereNode( diameter, {
        center: button.center,
        mainColor: '#b1b1b1',
        highlightColor: 'white',
        shadowColor: 'black',
        highlightXOffset: -0.2,
        highlightYOffset: -0.5
      } ) );
    }
    children.push( button );
    const nodeWithButton = new Node( { children: children } );

    const updateEnabled = () => {

      if ( scene.disturbanceTypeProperty.value === 'pulse' ) {
        button.enabled = !scene.pulseFiringProperty.value && !scene.isAboutToFireProperty.value;
      }

      else if ( scene.disturbanceTypeProperty.value === 'continuous' ) {
        button.enabled = true;
      }
    };

    // When changing between PULSE and CONTINUOUS, update the buttons.
    scene.disturbanceTypeProperty.link( disturbanceType => {

        pulseIcon.visible = disturbanceType === 'pulse';
        updateEnabled();
      }
    );
    scene.pulseFiringProperty.link( updateEnabled );
    scene.isAboutToFireProperty.link( updateEnabled );
    super( {
      children: [ nodeWithButton ]
    } );

    const sourceSeparationProperty = scene instanceof WaterScene ? scene.desiredSourceSeparationProperty : scene.sourceSeparationProperty;

    sourceSeparationProperty.link( sourceSeparation => {

      // Distance between the sources, or 0 if there is only 1 source
      const separation = scene.numberOfSources === 2 ? sourceSeparation : 0;
      if ( !isPrimarySource ) {
        nodeWithButton.visible = separation > 0;
      }
      const sign = isPrimarySource ? 1 : -1;
      const viewSeparation = scene.modelViewTransform!.modelToViewDeltaY( separation );

      nodeWithButton.centerY = waveAreaNode.centerY + sign * viewSeparation / 2 + verticalOffset;
    } );
  }
}

export default WaveGeneratorNode;
