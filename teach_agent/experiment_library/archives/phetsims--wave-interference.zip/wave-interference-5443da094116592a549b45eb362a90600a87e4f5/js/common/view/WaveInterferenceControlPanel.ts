// Copyright 2018-2026, University of Colorado Boulder

/**
 * Shows the main controls, including frequency/wavelength and amplitude.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import audioManager from '../../../../joist/js/audioManager.js';
import merge from '../../../../phet-core/js/merge.js';
import AlignGroup from '../../../../scenery/js/layout/constraints/AlignGroup.js';
import Line from '../../../../scenery/js/nodes/Line.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import WaveInterferenceStrings from '../../WaveInterferenceStrings.js';
import WavesModel from '../../waves/model/WavesModel.js';
import WaveInterferenceConstants from '../WaveInterferenceConstants.js';
import AmplitudeControl from './AmplitudeControl.js';
import FrequencyControl from './FrequencyControl.js';
import SceneRadioButtonGroup from './SceneRadioButtonGroup.js';
import SoundViewTypeRadioButtonGroup from './SoundViewTypeRadioButtonGroup.js';
import WaveInterferenceCheckbox from './WaveInterferenceCheckbox.js';
import WaveInterferencePanel, { WaveInterferencePanelOptions } from './WaveInterferencePanel.js';
import WaveInterferenceText from './WaveInterferenceText.js';

type SelfOptions = {

  // This additional control (if present) will be shown beneath the Amplitude slider in the WaveInterferenceControlPanel
  additionalControl?: Node | null;

  showIntensityCheckbox?: boolean;
  showSceneRadioButtons?: boolean;
  showPlaySoundControl?: boolean;
  audioEnabled?: boolean;
};

export type WaveInterferenceControlPanelOptions = SelfOptions & WaveInterferencePanelOptions;

class WaveInterferenceControlPanel extends WaveInterferencePanel {

  /**
   * @param model
   * @param alignGroup - used to align the control panels on the right side of the lattice
   * @param [providedOptions] - options for the control panel content and layout
   * @param [audioOptions] - additional options merged on top of providedOptions (e.g. audioEnabled), provided
   *                         separately by some callers such as WavesScreenView
   */
  public constructor( model: WavesModel, alignGroup: AlignGroup, providedOptions?: WaveInterferenceControlPanelOptions, audioOptions?: WaveInterferenceControlPanelOptions ) {

    const options = merge( {

      additionalControl: null,

      showIntensityCheckbox: true,
      maxWidth: WaveInterferenceConstants.PANEL_MAX_WIDTH,
      yMargin: 4,
      showSceneRadioButtons: true,
      showPlaySoundControl: false,
      audioEnabled: true
    }, providedOptions, audioOptions ) as Required<SelfOptions> & WaveInterferencePanelOptions;

    const frequencyControl = new FrequencyControl( model );
    const amplitudeControl = new AmplitudeControl( model );

    let soundViewTypeRadioButtonGroup: SoundViewTypeRadioButtonGroup | null = null;
    if ( model.soundScene && model.soundScene.showSoundParticles ) {
      soundViewTypeRadioButtonGroup = new SoundViewTypeRadioButtonGroup( model );
    }

    const graphCheckbox = new WaveInterferenceCheckbox( model.showGraphProperty, new WaveInterferenceText( WaveInterferenceStrings.graphStringProperty, WaveInterferenceConstants.CONTROL_PANEL_TEXT_MAX_WIDTH_OPTIONS ) );
    const screenCheckbox = new WaveInterferenceCheckbox( model.showScreenProperty, new WaveInterferenceText( WaveInterferenceStrings.screenLabelStringProperty, WaveInterferenceConstants.CONTROL_PANEL_TEXT_MAX_WIDTH_OPTIONS ) );
    const intensityCheckbox = new WaveInterferenceCheckbox( model.showIntensityGraphProperty, new WaveInterferenceText( WaveInterferenceStrings.intensityStringProperty, WaveInterferenceConstants.CONTROL_PANEL_TEXT_MAX_WIDTH_OPTIONS ) );

    // Only enable the intensity checkbox when the screen is selected
    model.showScreenProperty.link( showScreen => intensityCheckbox.setEnabled( showScreen ) );

    const maxComponentWidth = _.max( [
      ...( soundViewTypeRadioButtonGroup ? [ soundViewTypeRadioButtonGroup.width ] : [] ),
      screenCheckbox.width,
      graphCheckbox.width,
      frequencyControl.width,
      amplitudeControl.width
    ] )!;
    const separator = new Line( 0, 0, maxComponentWidth, 0, {
      stroke: 'rgb( 100, 100, 100 )'
    } );

    // Set pointer areas for the checkboxes, now that we have the separator dimensions.
    const updatePointerAreas = ( checkbox: WaveInterferenceCheckbox ) => {
      checkbox.mouseArea = checkbox.localBounds.dilated( 2 ).withX( maxComponentWidth );
      checkbox.touchArea = checkbox.mouseArea;
    };

    updatePointerAreas( graphCheckbox );
    updatePointerAreas( screenCheckbox );
    updatePointerAreas( intensityCheckbox );

    // See also playToneCheckbox mouseArea/touchArea set below

    // SceneRadioButtonGroup requires non-null scenes; it is only constructed when showSceneRadioButtons is true,
    // which only occurs for screens that create all three scenes.
    const sceneRadioButtonGroup = options.showSceneRadioButtons ? new SceneRadioButtonGroup(
      model.waterScene!,
      model.soundScene!,
      model.lightScene!,
      model.sceneProperty
    ) : null;

    let playToneCheckbox: WaveInterferenceCheckbox | null = null;

    // Only show the Play Tone checkbox for the Sound Scene, if specified.
    if ( model.soundScene && options.showPlaySoundControl ) {
      playToneCheckbox = new WaveInterferenceCheckbox( model.soundScene.isTonePlayingProperty, new WaveInterferenceText( WaveInterferenceStrings.playToneStringProperty, WaveInterferenceConstants.CONTROL_PANEL_TEXT_MAX_WIDTH_OPTIONS ) );

      // In terms of PhET-iO, there could be a situation where a client wants to control the enabledProperty of the
      // sound-related checkboxes, and toggling the mute button in the navbar will override their customization. There
      // is precedent for handling this sort of situation in other sims, such as the neutralIndicatorNode in ph-scale
      // (phetsims/ph-scale#102) and the phaseDiagramContainer in states-of-matter (phetsims/states-of-matter#332).
      // Use audioManager.audioAndSoundEnabledProperty rather than soundManager.enabledProperty: after
      // https://github.com/phetsims/joist/issues/724, soundManager.enabledProperty listeners no longer fire, and the
      // checkbox should be enabled only when it is possible for the soundManager to produce output.
      audioManager.audioAndSoundEnabledProperty.link( enabled => {
        playToneCheckbox!.enabled = enabled;
      } );

      updatePointerAreas( playToneCheckbox );
    }

    // Horizontal layout
    const centerX = frequencyControl.centerX;
    frequencyControl.centerX = centerX;
    amplitudeControl.centerX = centerX;
    if ( options.additionalControl ) {options.additionalControl.centerX = centerX;}
    if ( sceneRadioButtonGroup ) { sceneRadioButtonGroup.centerX = centerX; }
    separator.centerX = centerX;
    const minX = _.min( [
      frequencyControl.left,
      amplitudeControl.left,
      ...( sceneRadioButtonGroup ? [ sceneRadioButtonGroup.left ] : [] )
    ] )!;

    // Align controls to the left
    if ( soundViewTypeRadioButtonGroup ) {
      soundViewTypeRadioButtonGroup.left = minX;
    }
    graphCheckbox.left = minX;
    screenCheckbox.left = minX;
    if ( playToneCheckbox ) {
      playToneCheckbox.left = minX;
    }

    // Indent the intensity checkbox
    intensityCheckbox.left = minX + 20;

    // Vertical layout
    amplitudeControl.top = frequencyControl.bottom + 7;
    const y = amplitudeControl.bottom + 5;

    // The Separation NumberControl is an additionalControl
    if ( options.additionalControl ) {
      options.additionalControl.top = y + 8;
      if ( sceneRadioButtonGroup ) {
        sceneRadioButtonGroup.top = options.additionalControl.bottom + 8 + 8;
      }
    }
    else {
      if ( sceneRadioButtonGroup ) {
        sceneRadioButtonGroup.top = y + 8;
      }
    }
    const HORIZONTAL_SEPARATOR_MARGIN = 7;
    const CHECKBOX_SPACING = 6;
    separator.top = sceneRadioButtonGroup ? ( sceneRadioButtonGroup.bottom + 8 ) : y;
    graphCheckbox.top = separator.bottom + HORIZONTAL_SEPARATOR_MARGIN;
    if ( playToneCheckbox ) {
      playToneCheckbox.top = graphCheckbox.bottom + CHECKBOX_SPACING;
    }
    if ( soundViewTypeRadioButtonGroup ) {
      soundViewTypeRadioButtonGroup.top = ( playToneCheckbox ? playToneCheckbox.bottom : graphCheckbox.bottom ) + CHECKBOX_SPACING + 2;
    }
    screenCheckbox.top = graphCheckbox.bottom + CHECKBOX_SPACING;
    intensityCheckbox.top = screenCheckbox.bottom + CHECKBOX_SPACING;

    const container = new Node();

    const createLightSonificationCheckbox = () => {

      const lastCheckbox = options.showIntensityCheckbox ? intensityCheckbox : screenCheckbox;

      // soundEffectEnabledProperty is only available on the LightScene, which is non-null when this is called.
      const soundEffectCheckbox = new WaveInterferenceCheckbox( model.lightScene!.soundEffectEnabledProperty, new WaveInterferenceText( WaveInterferenceStrings.soundEffectStringProperty, WaveInterferenceConstants.CONTROL_PANEL_TEXT_MAX_WIDTH_OPTIONS ), {
        top: lastCheckbox.bottom + CHECKBOX_SPACING,
        left: screenCheckbox.left
      } );

      // In terms of PhET-iO, there could be a situation where a client wants to control the enabledProperty of the
      // sound-related checkboxes, and toggling the mute button in the navbar will override their customization. There
      // is precedent for handling this sort of situation in other sims, such as the neutralIndicatorNode in ph-scale
      // (phetsims/ph-scale#102) and the phaseDiagramContainer in states-of-matter (phetsims/states-of-matter#332).
      // Use audioManager.audioAndSoundEnabledProperty rather than soundManager.enabledProperty: after
      // https://github.com/phetsims/joist/issues/724, soundManager.enabledProperty listeners no longer fire, and the
      // checkbox should be enabled only when it is possible for the soundManager to produce output.
      audioManager.audioAndSoundEnabledProperty.link( enabled => {
        soundEffectCheckbox.enabled = enabled;
      } );
      updatePointerAreas( soundEffectCheckbox );

      return soundEffectCheckbox;
    };

    // Update when the scene changes.  Add and remove children so that the panel changes size (has resize:true)
    model.sceneProperty.link( scene => {

      // z-ordering
      container.children = [

        frequencyControl,
        amplitudeControl,

        ...( options.additionalControl ? [ options.additionalControl ] : [] ),
        ...( sceneRadioButtonGroup ? [ sceneRadioButtonGroup ] : [] ),
        separator,
        graphCheckbox,

        ...( scene === model.soundScene && playToneCheckbox ? [ playToneCheckbox ] : [] ),

        // Wave/Particle selection only for Sound scene
        ...( scene === model.soundScene && model.soundScene.showSoundParticles && soundViewTypeRadioButtonGroup ? [ soundViewTypeRadioButtonGroup ] : [] ),

        // Screen & Intensity graph should only be available for light scenes. Remove it from water and sound.
        ...( scene === model.lightScene ? [ screenCheckbox ] : [] ),
        ...( scene === model.lightScene && options.showIntensityCheckbox ? [ intensityCheckbox ] : [] ),
        ...( scene === model.lightScene ? [ createLightSonificationCheckbox() ] : [] )
      ];
    } );

    const content = alignGroup.createBox( container );

    super( content, options );
  }
}

export default WaveInterferenceControlPanel;
