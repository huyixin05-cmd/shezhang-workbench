// Copyright 2018-2026, University of Colorado Boulder

/**
 * This node is used for layout only.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import merge from '../../../../phet-core/js/merge.js';
import Rectangle, { RectangleOptions } from '../../../../scenery/js/nodes/Rectangle.js';
import WaveInterferenceConstants from '../WaveInterferenceConstants.js';

class WaveAreaNode extends Rectangle {

  public constructor( options?: RectangleOptions ) {
    super( 0, 0, WaveInterferenceConstants.WAVE_AREA_WIDTH, WaveInterferenceConstants.WAVE_AREA_WIDTH, merge( {

      // This node is used for layout, so don't include a stroke which could throw off the dimensions
      // Show the background color required for the sound scene, when the lattice is hidden
      fill: '#4c4c4c'
    }, options ) );
  }
}

export default WaveAreaNode;
