// Copyright 2018-2026, University of Colorado Boulder
/**
 * Controls the separation of the sources for each Scene.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import Range from '../../../../dot/js/Range.js';
import { roundToInterval } from '../../../../dot/js/util/roundToInterval.js';
import { combineOptions } from '../../../../phet-core/js/optionize.js';
import NumberControl, { NumberControlMajorTick, NumberControlOptions } from '../../../../scenery-phet/js/NumberControl.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import ToggleNode from '../../../../sun/js/ToggleNode.js';
import Scene from '../../common/model/Scene.js';
import WaveInterferenceText from '../../common/view/WaveInterferenceText.js';
import WaveInterferenceConstants from '../../common/WaveInterferenceConstants.js';
import WaveInterferenceStrings from '../../WaveInterferenceStrings.js';
import InterferenceModel from '../model/InterferenceModel.js';

class SeparationControl extends ToggleNode<Scene> {

  public constructor( model: InterferenceModel ) {

    // Ranges, deltas, etc specified in https://github.com/phetsims/wave-interference/issues/177
    const waterSeparationProperty = model.waterScene!.desiredSourceSeparationProperty;
    const soundSeparationProperty = model.soundScene!.sourceSeparationProperty;
    const lightSeparationProperty = model.lightScene!.sourceSeparationProperty;

    const waterSceneRange = waterSeparationProperty.range;
    const soundSceneRange = soundSeparationProperty.range;
    const lightSceneRange = lightSeparationProperty.range;
    const allRanges = [ waterSceneRange, soundSceneRange, lightSceneRange ];

    const createMuteOptions = ( scene: Scene ) => {
      return {
        startCallback: () => scene.setMuted( true ),
        endCallback: () => scene.setMuted( false )
      };
    };

    // Switch between controls for each scene.  No advantage in using SceneToggleNode in this case
    // because the control constructor calls are substantially different.
    super( model.sceneProperty, [ {
      value: model.waterScene!,
      createNode: () => {

        // Captured so constrainValue can use a finer snap interval while Shift is held (keeping mouse snapping at 0.5 cm).
        const waterNumberControl: NumberControl = new NumberControl( WaveInterferenceStrings.separationStringProperty, waterSeparationProperty, waterSceneRange, combineOptions<NumberControlOptions>( {
          delta: 0.1,
          numberDisplayOptions: {
            decimalPlaces: 1
          },
          sliderOptions: {

            // Keyboard steps in cm: 0.5 normally, 0.1 with Shift (matching the increment/decrement button amount).
            keyboardStep: 0.5,
            shiftKeyboardStep: 0.1,
            pageKeyboardStep: 1,
            constrainValue: value => roundToInterval( value, waterNumberControl.slider.shiftKeyDown ? 0.1 : 0.5 ),
            majorTicks: createTicks( waterSceneRange, allRanges )
          }
        }, createMuteOptions( model.waterScene! ), WaveInterferenceConstants.NUMBER_CONTROL_OPTIONS ) );
        return waterNumberControl;
      }
    }, {

      value: model.soundScene!,
      createNode: () => {

        // Captured so constrainValue can use a finer snap interval while Shift is held (keeping mouse snapping at 10 cm).
        const soundNumberControl: NumberControl = new NumberControl( WaveInterferenceStrings.separationStringProperty, soundSeparationProperty, soundSceneRange, combineOptions<NumberControlOptions>( {
          delta: 1,
          sliderOptions: {

            // Keyboard steps in cm: 10 normally, 1 with Shift.
            keyboardStep: 10,
            shiftKeyboardStep: 1,
            pageKeyboardStep: 50,
            constrainValue: value => roundToInterval( value, soundNumberControl.slider.shiftKeyDown ? 1 : 10 ),
            majorTicks: createTicks( soundSceneRange, allRanges )
          }
        }, createMuteOptions( model.soundScene! ), WaveInterferenceConstants.NUMBER_CONTROL_OPTIONS ) );
        return soundNumberControl;
      }
    }, {

      value: model.lightScene!,
      createNode: () => {

        // Captured so constrainValue can use a finer snap interval while Shift is held (keeping mouse snapping at 100 nm).
        const lightNumberControl: NumberControl = new NumberControl( WaveInterferenceStrings.separationStringProperty, lightSeparationProperty, lightSceneRange, combineOptions<NumberControlOptions>( {
          delta: 10,
          sliderOptions: {

            // Keyboard steps in nm: 100 normally, 10 with Shift.
            keyboardStep: 100,
            shiftKeyboardStep: 10,
            pageKeyboardStep: 500,
            constrainValue: value => roundToInterval( value, lightNumberControl.slider.shiftKeyDown ? 10 : 100 ),
            majorTicks: createTicks( lightSceneRange, allRanges )
          }
        }, createMuteOptions( model.lightScene! ), WaveInterferenceConstants.NUMBER_CONTROL_OPTIONS ) );
        return lightNumberControl;
      }
    } ] );
  }
}


/**
 * Create a label for a NumberControl tick.  The labels have the same bounds for each slider so
 * they don't jitter when changing scenes, see https://github.com/phetsims/wave-interference/issues/214
 * @param string - the string to display
 * @param allStrings - the strings for each scene, for layout
 */
const createTickMarkLabel = ( string: string, allStrings: string[] ): Node => {
  const textNodes = allStrings.map( s => new WaveInterferenceText( s, {
      fontSize: WaveInterferenceConstants.TICK_FONT_SIZE,
      maxWidth: WaveInterferenceConstants.TICK_MAX_WIDTH,
      visible: s === string,
      centerX: 0
    } )
  );
  return new Node( { children: textNodes } );
};

/**
 * Create the min and max ticks for a NumberControl
 * @param range
 * @param allRanges - to ensure consistent layout across scenes
 * @returns to be used with numberTicks option of NumberControl
 */
const createTicks = ( range: Range, allRanges: Range[] ): NumberControlMajorTick[] => [
  { value: range.min, label: createTickMarkLabel( range.min + '', allRanges.map( r => r.min + '' ) ) },
  { value: range.max, label: createTickMarkLabel( range.max + '', allRanges.map( r => r.max + '' ) ) }
];

export default SeparationControl;
