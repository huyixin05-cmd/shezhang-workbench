# Wave Interference - Release Notes
<!-- 
Instructions:
* Replace {{SIM_TITLE}} with the simulation title.
* Replace {{VERSION}} with the version number, in MAJOR.MINOR format, e.g. "1.2".
* For a published version, replace {{PUBLICATION_DATE}} with the publication date, in year-month-day format, e.g. "2025-05-16".
* For a version that has not been published yet, replace {{PUBLICATION_DATE}} with "in progress".
* For a 1.0 release, only the 1.0 heading and date is needed. This includes ports of legacy sims.
* Developer and designer should collaborate on what to include for any release beyond 1.0. 
* For each new version, add a section to the top of these release notes - reverse chronological order, with the most-recent version at the top.

For an exemplar, see https://github.com/phetsims/balancing-chemical-equations/blob/main/doc/release-notes.md
-->

<!-- 
## {{MAJOR.MINOR}} ({{PUBLICATION_DATE}})

### New Features
* Describe a new feature.
* 

### Bug Fixes
* Describe a bug fix.
* 

### Other Changes
* Describe a change.
* ⚠️ Use this icon for a change that is breaking, removes a feature, etc. 
*
-->

## 2.1 (in progress)

### New Features
* Preferences
* TypeScript implementation
* Dynamic Locale: see _Preferences > Localization > Languages_
* Sound and Sonification
* Alternative Input
* Interactive Highlights: see _Preferences > Visual > Interactive Highlights_
* Pan and Zoom

### Bug Fixes
* An unintended sine wave tone no longer plays when the sim starts.

### Other Changes
* Now versioned together with Waves Intro.
* Improved ducking for the Wave Meter sound.
* Improved color contrast.

## 2.0 (2019-09-23)

### New Features
* New _Diffraction_ screen, with several aperture shapes (circle, ellipse, rectangle, and more) that produce diffraction patterns.

## 1.0 (2019-01-30)
