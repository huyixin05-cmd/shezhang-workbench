// Copyright 2015-2026, University of Colorado Boulder

/**
 * Namespace object for Molecule Shapes
 *
 * @author Jonathan Olson (PhET Interactive Simulations)
 */

import Namespace from '../../phet-core/js/Namespace.js';

export default new Namespace( 'moleculeShapes' );