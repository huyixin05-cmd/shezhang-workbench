// Copyright 2021-2026, University of Colorado Boulder

/**
 * @author Sam Reid (PhET Interactive Simulations)
 */

import Enumeration from '../../../../phet-core/js/Enumeration.js';
import EnumerationValue from '../../../../phet-core/js/EnumerationValue.js';

export default class LaserViewEnum extends EnumerationValue {
  public static readonly RAY = new LaserViewEnum();
  public static readonly WAVE = new LaserViewEnum();

  private static readonly enumeration = new Enumeration( LaserViewEnum );
}
