// Copyright 2024-2026, University of Colorado Boulder

/**
 * Defines query parameters that are specific to this simulation.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 */

import logGlobal from '../../phet-core/js/logGlobal.js';
import { QueryStringMachine } from '../../query-string-machine/js/QueryStringMachineModule.js';

const BendingLightQueryParameters = QueryStringMachine.getAll( {

  /**
   * The number of steps a light ray is allowed to reflect/refract before it is considered to be lost.
   */
  maxLightRaySteps: {
    type: 'number' as const,
    defaultValue: 50
  }
} );

// Log query parameters
logGlobal( 'phet.chipper.queryParameters' );
logGlobal( 'phet.preloads.phetio.queryParameters' );
phet.log && phet.log( `BendingLightQueryParameters: ${JSON.stringify( BendingLightQueryParameters, null, 2 )}` );

export default BendingLightQueryParameters;
