// Copyright 2016-2026, University of Colorado Boulder

/**
 * View-specific Properties for the 'My Solution' and 'Micro' screens.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 */

import BooleanProperty from '../../../../axon/js/BooleanProperty.js';
import Property from '../../../../axon/js/Property.js';
import Tandem from '../../../../tandem/js/Tandem.js';

export default class PHScaleViewProperties {

  public readonly ratioVisibleProperty: Property<boolean>;
  public readonly particleCountsVisibleProperty: Property<boolean>;

  public constructor( tandem: Tandem ) {

    this.ratioVisibleProperty = new BooleanProperty( false, {
      tandem: tandem.createTandem( 'ratioVisibleProperty' ),
      phetioFeatured: true,
      phetioDocumentation: 'controls visibility of the H3O+/OH- Ratio view'
    } );

    this.particleCountsVisibleProperty = new BooleanProperty( false, {
      tandem: tandem.createTandem( 'particleCountsVisibleProperty' ),
      phetioFeatured: true,
      phetioDocumentation: 'controls visibility of the Particle Counts view'
    } );
  }

  public reset(): void {
    this.ratioVisibleProperty.reset();
    this.particleCountsVisibleProperty.reset();
  }
}
