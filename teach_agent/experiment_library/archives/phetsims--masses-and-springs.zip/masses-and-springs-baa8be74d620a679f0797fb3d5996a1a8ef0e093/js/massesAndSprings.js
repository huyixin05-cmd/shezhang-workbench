// Copyright 2016-2020, University of Colorado Boulder

/**
 * Creates the namespace for this simulation.
 *
 * @author Matt Pennington (PhET Interactive Simulations)
 */

import Namespace from '../../phet-core/js/Namespace.js';

export default new Namespace( 'massesAndSprings' );