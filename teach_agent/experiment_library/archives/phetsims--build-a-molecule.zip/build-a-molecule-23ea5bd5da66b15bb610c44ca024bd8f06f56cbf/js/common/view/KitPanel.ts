// Copyright 2020-2026, University of Colorado Boulder

/**
 * Contains the kit background and controls for switching between kits
 *
 * @author Denzell Barnett (PhET Interactive Simulations)
 * @author Jonathan Olson (PhET Interactive Simulations)
 */

import Property from '../../../../axon/js/Property.js';
import Display from '../../../../scenery/js/display/Display.js';
import Node from '../../../../scenery/js/nodes/Node.js';
import Color from '../../../../scenery/js/util/Color.js';
import Carousel from '../../../../sun/js/Carousel.js';
import PageControl from '../../../../sun/js/PageControl.js';
import nullSoundPlayer from '../../../../tambo/js/nullSoundPlayer.js';
import BAMConstants from '../BAMConstants.js';
import KitCollection from '../model/KitCollection.js';
import BAMScreenView from './BAMScreenView.js';
import KitNode from './KitNode.js';

export default class KitPanel extends Node {

  public readonly kitCarousel: Carousel;

  public constructor( kitCollection: KitCollection, kitNodeWidth: number, kitNodeHeight: number, view: BAMScreenView, isCollectingView: boolean ) {
    super();

    // Keep track of the KitCollection
    const kitCollectionProperty = new Property( kitCollection );

    // create kitNodes and unify their heights
    const kitNodes: Array<{ createNode: () => KitNode }> = [];
    kitCollectionProperty.link( kitCollection => {
      kitCollection.kits.forEach( kit => {

        kitNodes.push( {

          createNode: () => {

            const kitNode = new KitNode( kit, view );
            const kitNodeBounds = kitNode.getLocalBounds();
            kitNode.setLocalBounds( kitNodeBounds.dilatedY( ( kitNodeHeight - kitNodeBounds.getHeight() ) / 2 ) );

            // We only want to adjust width of kit panel on collection views.
            if ( isCollectingView ) {
              kitNode.setLocalBounds( kitNodeBounds.dilatedX( ( kitNodeWidth - kitNodeBounds.getWidth() ) / 2 ) );
            }
            else {
              kitNode.setLocalBounds( kitNodeBounds.dilatedX( ( kitNodeWidth - kitNodeBounds.getWidth() ) * 0.02 ) );
            }
            return kitNode;
          }
        } );
      } );
    } );

    // Treats each kit as an item in the Carousel.
    this.kitCarousel = new Carousel( kitNodes, {
      fill: BAMConstants.KIT_BACKGROUND,
      stroke: BAMConstants.KIT_BORDER,
      itemsPerPage: 1,
      buttonOptions: {
        soundPlayer: nullSoundPlayer,
        interruptListener: Display.INTERRUPT_OTHER_POINTERS
      }
    } );
    this.kitCarousel.isAnimatingProperty.link( isAnimating => {
      this.kitCarousel.pickable = !isAnimating;
    } );

    // When the page number changes update the current collection.
    this.kitCarousel.pageNumberProperty.link( page => {

      kitCollectionProperty.value.currentKitProperty.value = kitCollectionProperty.value.kits[ page ];
    } );
    this.addChild( this.kitCarousel );

    // Page control for input carousel
    const inputPageControl = new PageControl( this.kitCarousel.pageNumberProperty, this.kitCarousel.numberOfPagesProperty, {
      top: this.kitCarousel.bottom + BAMConstants.VIEW_PADDING / 2,
      centerX: this.kitCarousel.centerX,
      pageFill: Color.WHITE,
      pageStroke: Color.BLACK,
      interactive: true
    } );
    this.addChild( inputPageControl );
  }

  public reset(): void {
    this.kitCarousel.reset();
  }
}
