export default {
  attach: function() {}
};
