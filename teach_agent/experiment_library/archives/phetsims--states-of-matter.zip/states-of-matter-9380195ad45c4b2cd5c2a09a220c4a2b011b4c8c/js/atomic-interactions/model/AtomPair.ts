// Copyright 2015-2026, University of Colorado Boulder

/**
 * AtomPair enumeration
 * @author John Blanco (PhET Interactive Simulations)
 */

import EnumerationDeprecated from '../../../../phet-core/js/EnumerationDeprecated.js';
import IntentionalAny from '../../../../phet-core/js/types/IntentionalAny.js';
import AtomType from '../../common/model/AtomType.js';

const AtomPair = EnumerationDeprecated.byMap( {
    NEON_NEON: { fixedAtomType: AtomType.NEON, movableAtomType: AtomType.NEON },
    ARGON_ARGON: { fixedAtomType: AtomType.ARGON, movableAtomType: AtomType.ARGON },
    OXYGEN_OXYGEN: { fixedAtomType: AtomType.OXYGEN, movableAtomType: AtomType.OXYGEN },
    NEON_ARGON: { fixedAtomType: AtomType.NEON, movableAtomType: AtomType.ARGON },
    NEON_OXYGEN: { fixedAtomType: AtomType.NEON, movableAtomType: AtomType.OXYGEN },
    ARGON_OXYGEN: { fixedAtomType: AtomType.ARGON, movableAtomType: AtomType.OXYGEN },
    ADJUSTABLE: { fixedAtomType: AtomType.ADJUSTABLE, movableAtomType: AtomType.ADJUSTABLE }
  }
) as IntentionalAny;

export default AtomPair;
