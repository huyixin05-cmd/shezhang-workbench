// Copyright 2015-2026, University of Colorado Boulder

/**
 * Scenery node that shows the grid lines.  Highly leveraged from energy-skate-park's GridNode implementation.
 *
 * @author Sam Reid (PhET Interactive Simulations)
 * @author Siddhartha Chinthapally
 */

import NumberProperty from '../../../../axon/js/NumberProperty.js';
import Range from '../../../../dot/js/Range.js';
import Shape from '../../../../kite/js/Shape.js';
import optionize from '../../../../phet-core/js/optionize.js';
import MagnifyingGlassZoomButtonGroup from '../../../../scenery-phet/js/MagnifyingGlassZoomButtonGroup.js';
import Node, { NodeOptions } from '../../../../scenery/js/nodes/Node.js';
import Path from '../../../../scenery/js/nodes/Path.js';
import ButtonNode from '../../../../sun/js/buttons/ButtonNode.js';
import Tandem from '../../../../tandem/js/Tandem.js';
import PotentialGraphNode from '../../common/view/PotentialGraphNode.js';
import SOMColors from '../../common/view/SOMColors.js';

// constants
const MIN_LINES_HORIZONTAL = 5;
const GRID_LINES_OPTIONS = {
  stroke: SOMColors.ljGraphAxesAndGridColorProperty,
  lineWidth: 0.8,
  opacity: 0.6
};

type SelfOptions = {
  addZoomButtons?: boolean;
};

type ZoomableGridNodeOptions = SelfOptions & NodeOptions;

class ZoomableGridNode extends Node {

  // horizontal grid lines
  private readonly horizontalLinesNode: Path;

  // zoom level, passed in to the zoom button group if zoom is enabled
  private readonly zoomFactorProperty: NumberProperty;

  /**
   * @param atomsView
   * @param offsetX
   * @param offsetY
   * @param width - width of the graph
   * @param height - height of the graph
   * @param providedOptions
   */
  public constructor( atomsView: PotentialGraphNode, offsetX: number, offsetY: number, width: number, height: number, providedOptions?: ZoomableGridNodeOptions ) {

    const options = optionize<ZoomableGridNodeOptions, SelfOptions, NodeOptions>()( {
      addZoomButtons: true,
      tandem: Tandem.REQUIRED
    }, providedOptions );

    atomsView.horizontalLineCount = MIN_LINES_HORIZONTAL;

    super( options );

    this.horizontalLinesNode = new Path( null, GRID_LINES_OPTIONS );

    // vertical grid lines
    const verticalLinesNode = new Path( null, GRID_LINES_OPTIONS );

    this.zoomFactorProperty = new NumberProperty( 0, {
      tandem: options.tandem.createTandem( 'zoomFactorProperty' ),
      range: new Range( -2, 0 )
    } );

    if ( options.addZoomButtons ) {

      // Create the zoom button group that will allow the user to zoom in and out on the vertical range of the grid.
      const zoomButtonGroup = new MagnifyingGlassZoomButtonGroup( this.zoomFactorProperty, {
        orientation: 'vertical',
        spacing: 5,

        // Position the zoom buttons to the left and top of the grid.  The numerical values were empirically determined
        // to match the design.
        right: offsetX - 15,
        top: offsetY - 5,

        magnifyingGlassNodeOptions: {
          glassRadius: 8
        },
        buttonOptions: {
          baseColor: '#FFD333',
          buttonAppearanceStrategy: ButtonNode.FlatAppearanceStrategy,
          xMargin: 3,
          yMargin: 3
        },
        touchAreaXDilation: 8,
        touchAreaYDilation: 8,
        tandem: options.tandem.createTandem( 'zoomButtonGroup' )
      } );
      this.addChild( zoomButtonGroup );

      // Keep a record of the default scaling factor so that we can use it for scaling up and down.
      const nominalScalingFactor = atomsView.verticalScalingFactor;

      // Update the vertical scale of the graph as well as the number of horizontal lines when the zoom level changes.
      this.zoomFactorProperty.lazyLink( zoomFactor => {
        atomsView.horizontalLineCount = MIN_LINES_HORIZONTAL - 2 * zoomFactor; // empirically determined to look decent
        this.updateHorizontalLines( offsetX, offsetY, width, height, atomsView.horizontalLineCount );
        atomsView.verticalScalingFactor = nominalScalingFactor * Math.pow( 3.33, zoomFactor );
        atomsView.drawPotentialCurve();
      } );
    }

    // Add the vertical grid lines.
    const verticalLineShape = new Shape();
    for ( let x = 0; x < 4; x++ ) {
      const viewX = x * ( width / 3 );
      verticalLineShape.moveTo( viewX + offsetX, offsetY );
      verticalLineShape.lineTo( viewX + offsetX, height + offsetY );
    }
    verticalLinesNode.setShape( verticalLineShape );
    this.addChild( verticalLinesNode );

    // Add the horizontal grid lines.
    this.updateHorizontalLines( offsetX, offsetY, width, height, atomsView.horizontalLineCount );
    this.addChild( this.horizontalLinesNode );
  }

  /**
   * @param offsetX
   * @param offsetY
   * @param width -- width of the grid
   * @param height -- height of the grid
   * @param horizontalLineCount -- number of horizontal lines
   */
  public updateHorizontalLines( offsetX: number, offsetY: number, width: number, height: number, horizontalLineCount: number ): void {
    const horizontalLineShape = new Shape();
    for ( let y = 0; y < horizontalLineCount; y++ ) {
      const viewY = y * ( height / ( horizontalLineCount - 1 ) );
      horizontalLineShape.moveTo( offsetX, viewY + offsetY );
      horizontalLineShape.lineTo( width + offsetX, viewY + offsetY );
    }
    this.horizontalLinesNode.setShape( horizontalLineShape );
  }

  /**
   * restore initial state
   */
  public reset(): void {
    this.zoomFactorProperty.reset();
  }
}

export default ZoomableGridNode;
