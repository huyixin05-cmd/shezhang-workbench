// Copyright 2015-2026, University of Colorado Boulder

/**
 * A pseudo-3D sphere with a halo that appears during interactions.  This was highly leveraged from Manipulator.js
 * in the Graphing Lines simulation.
 *
 * @author Chris Malley (PixelZoom, Inc.)
 * @author Siddhartha Chinthapally (Actual Concepts)
 */

import Shape from '../../../../kite/js/Shape.js';
import optionize from '../../../../phet-core/js/optionize.js';
import ShadedSphereNode, { ShadedSphereNodeOptions } from '../../../../scenery-phet/js/ShadedSphereNode.js';
import PressListener from '../../../../scenery/js/listeners/PressListener.js';
import Circle from '../../../../scenery/js/nodes/Circle.js';
import Node, { NodeOptions } from '../../../../scenery/js/nodes/Node.js';
import Color from '../../../../scenery/js/util/Color.js';
import RadialGradient from '../../../../scenery/js/util/RadialGradient.js';
import Tandem from '../../../../tandem/js/Tandem.js';

type SelfOptions = {
  shadedSphereNodeOptions?: ShadedSphereNodeOptions;
  haloAlpha?: number; // alpha channel of the halo, 0.0 - 1.0
};

type PositionMarkerOptions = SelfOptions & NodeOptions;

class PositionMarker extends Node {

  private readonly radius: number;
  private readonly haloNode: Circle;
  private readonly sphereNode: ShadedSphereNode;

  /**
   * @param radius - radius of the sphere
   * @param color - base color used to shade the sphere
   * @param providedOptions
   */
  public constructor( radius: number, color: Color | string, providedOptions?: PositionMarkerOptions ) {
    const mainColor = Color.toColor( color );
    const options = optionize<PositionMarkerOptions, SelfOptions, NodeOptions>()( {
      shadedSphereNodeOptions: {
        mainColor: mainColor,
        highlightColor: Color.WHITE,
        shadowColor: mainColor.darkerColor(),
        stroke: mainColor.darkerColor(),
        lineWidth: 1,
        cursor: 'pointer'
      },
      haloAlpha: 0.5, // alpha channel of the halo, 0.0 - 1.0
      cursor: 'pointer',
      tandem: Tandem.REQUIRED
    }, providedOptions );

    const haloNode = new Circle( 1.75 * radius, {
      fill: mainColor.withAlpha( options.haloAlpha ),
      pickable: false,
      visible: false
    } );
    const sphereNode = new ShadedSphereNode( 2 * radius, options.shadedSphereNodeOptions );

    super( {
      children: [ haloNode, sphereNode ],
      tandem: options.tandem,
      phetioInputEnabledPropertyInstrumented: true
    } );

    this.radius = radius;
    this.haloNode = haloNode;
    this.sphereNode = sphereNode;

    // halo visibility
    const pressListener = new PressListener( { attach: false, tandem: options.tandem.createTandem( 'pressListener' ) } );
    this.addInputListener( pressListener );
    this.haloNode.visibleProperty = pressListener.isHighlightedProperty;

    // expand pointer areas
    this.mouseArea = this.touchArea = Shape.circle( 0, 0, 1.5 * radius );
  }

  public changeColor( color: Color | string ): void {
    this.haloNode.fill = Color.toColor( color ).withAlpha( 0.5 );
    const mainColor = Color.toColor( color );
    const highlightColor = Color.WHITE;
    const shadowColor = mainColor.darkerColor();
    this.sphereNode.fill = new RadialGradient( this.radius * -0.4, this.radius * -0.4, 0, this.radius * -0.4,
      this.radius * -0.4, 2 * this.radius )
      .addColorStop( 0, highlightColor )
      .addColorStop( 0.5, mainColor )
      .addColorStop( 1, shadowColor );
    this.sphereNode.stroke = shadowColor;
  }
}

export default PositionMarker;
