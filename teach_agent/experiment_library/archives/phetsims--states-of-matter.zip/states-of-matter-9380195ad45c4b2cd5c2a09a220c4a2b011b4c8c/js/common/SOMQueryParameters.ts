// Copyright 2016-2026, University of Colorado Boulder

/**
 * Query parameters supported by this simulation.
 *
 * @author John Blanco
 */

import { QueryStringMachine } from '../../../query-string-machine/js/QueryStringMachineModule.js';

const SOMQueryParameters = QueryStringMachine.getAll( {

  // Default to displaying degrees Celsius instead of Kelvin, requested by user(s), see
  // https://github.com/phetsims/states-of-matter/issues/216
  defaultCelsius: {
    type: 'flag',
    public: true
  },

  // make the burners sticky, see https://github.com/phetsims/states-of-matter/issues/295
  stickyBurners: {
    type: 'flag',
    public: true
  }

} );

export default SOMQueryParameters;
