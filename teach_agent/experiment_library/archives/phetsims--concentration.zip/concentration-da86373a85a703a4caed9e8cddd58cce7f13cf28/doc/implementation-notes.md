# Concentration - implementation notes

This simulation consists of the _Concentration_ screen from the _Beer's Law Lab_ simulation.
Please see [beers-law-lab/doc/implementation-notes.md](https://github.com/phetsims/beers-law-lab/blob/main/doc/implementation-notes.md) for model details.